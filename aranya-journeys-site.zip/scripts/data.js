/* ==========================================================================
   ARANYA JOURNEYS — CURATED DATA STORE & SIMPLE CLIENT CMS LAYER
   ========================================================================== */

const STORAGE_KEY = "aranya_cms_packages_v1";

const BUSINESS_CREDENTIALS = {
  brand: "Aranya Journeys",
  tagline: "Quiet Luxury Across India",
  foundedYear: 2016,
  yearsInBusiness: "10+ Years",
  motLicense: "MOT/TOUR/2016/08419",
  iataNumber: "IATA #14-3-6829-4",
  gstin: "29AABCA8419K1Z5",
  googleRating: "4.9",
  googleReviewCount: 642,
  googleMapsUrl: "https://www.google.com/maps/search/?api=1&query=Lavelle+Road+Bengaluru+560001",
  phoneDisplay: "+91 98114 72090",
  phoneRaw: "919811472090",
  curatorName: "Priya Nair",
  curatorRole: "Senior Trip Curator",
  curatorPhoto: "assets/images/curator-priya.jpg",
  founderName: "Aarav Mehta",
  founderPhoto: "assets/images/founder-aarav.jpg",
  email: "concierge@aranyajourneys.in",
  hqAddress: "No. 42, 2nd Floor, Lavelle Road, Shanthala Nagar, Bengaluru, Karnataka 560001",
  fieldAddress: "Deodar Lane, Old Manali Road, Manali, Himachal Pradesh 175131",
  workingHours: "Mon – Sat, 9:30 AM – 7:30 PM IST (24×7 On-Trip Support)"
};

const DEFAULT_PACKAGES = [
  {
    id: "pkg-manali",
    slug: "manali-honeymoon-package",
    seoTitle: "Manali Honeymoon & Deodar Eco-Stay Package (6 Days) | Aranya Journeys",
    seoDescription: "Private 6-day Old Manali & Sethan cedar sanctuary retreat with transparent all-inclusive pricing, private Innova Hycross, and boutique mountain chalets.",
    title: "Manali & Sethan Deodar Sanctuary",
    location: "Himachal Pradesh · Old Manali & Sethan",
    duration: "5 Nights · 6 Days",
    price: 48500,
    rating: "4.9",
    reviewCount: 148,
    badge: "Bestseller",
    secondaryBadge: "Eco Stay",
    categories: ["mountains", "honeymoon", "eco"],
    urgency: "Only 4 seats left for 12 Dec batch",
    batches: ["12 Dec – 17 Dec", "20 Dec – 25 Dec", "04 Jan – 09 Jan", "18 Jan – 23 Jan"],
    heroImage: "assets/images/pkg-manali.jpg",
    gallery: [
      "assets/images/pkg-manali.jpg",
      "assets/images/hero-himalayas.jpg",
      "assets/images/traveler-chai.jpg"
    ],
    summaryLine: "Timber-and-stone mountain chalets · Private SUV · Farm-to-table breakfasts & dinners · Forest permits",
    overview: "Designed for couples and slow travellers who want the Himalayas without Mall Road crowds. Spend three nights in a private cedar-framed chalet above Old Manali and two nights in snow-quiet Sethan hamlet facing the Pir Panjal range.",
    priceBreakup: [
      { label: "5 Nights Boutique Heritage & Eco-Chalet Stays", amount: 26500 },
      { label: "Private Chauffeur-Driven Toyota Hycross (Chandigarh/Bhuntar pickup)", amount: 11200 },
      { label: "Daily Artisanal Breakfasts, 4 Slow Dinners & Orchard Picnic", amount: 8490 },
      { label: "Forest Trail Permits, Local Naturalist & 5% GST", amount: 2310 }
    ],
    inclusions: [
      "5 nights in hand-inspected boutique mountain chalets with heated bedding",
      "Dedicated private SUV from Chandigarh or Bhuntar airport with experienced hill driver",
      "Daily breakfast, evening Himalayan herbal tea & 4 curated local dinners",
      "Guided silent cedar walk in Hampta valley with local naturalist",
      "Private bonfire evening & stargazing deck in Sethan",
      "All forest entry permits, tolls, driver allowances & 5% GST (Zero hidden charges)"
    ],
    exclusions: [
      "Flights to Chandigarh / Bhuntar (we assist with best fare booking at zero markup)",
      "Lunches at local cafés so you can explore effortlessly at your own pace",
      "Personal adventure gear rentals (skiing / paragliding if opted)"
    ],
    itinerary: [
      {
        day: "Day 1",
        title: "Arrival & Ascent Along the Beas River to Old Manali",
        meta: "Drive: 1.5 hrs from Bhuntar · Alt: 2,050m · Breakfast & Dinner",
        detail: "Your private driver greets you at Bhuntar (or Chandigarh). Settle into a timber-and-slate chalet tucked inside an apple and deodar orchard far above town traffic. Unwind on your private balcony with roasted Kullu trout or Siddu dinner."
      },
      {
        day: "Day 2",
        title: "Morning Cedar Forest Walk & Jana Waterfall Slow Lunch",
        meta: "Easy 4 km walk · Alt: 2,200m · Breakfast & Dinner",
        detail: "Walk ancient forest trails with our local naturalist Tenzin, spotting Himalayan monals and giant deodars. Afternoon traditional Himachali thali cooked on woodfire above Jana village."
      },
      {
        day: "Day 3",
        title: "Naggar Castle Heritage, Nicholas Roerich Estate & Pottery Studio",
        meta: "25 min scenic drive · Leisurely pace · Breakfast",
        detail: "Explore kath-kuni stone-and-wood architecture at Naggar Castle, quiet mountain art galleries, and an unhurried afternoon coffee overlooking the Kullu valley."
      },
      {
        day: "Day 4",
        title: "Climb to Off-Grid Sethan Snow Hamlet (Hampta Valley)",
        meta: "45 min ascent · Alt: 2,700m · Breakfast & Dinner",
        detail: "Ascend 35 hairpin bends through silver birch trees to Sethan, a tiny Buddhist village of 25 homes facing Deo Tibba peak. Check into a glass-fronted eco-dome chalet with wood-burningbukhari stove."
      },
      {
        day: "Day 5",
        title: "Private Ridge Trail Picnic & High-Altitude Stargazing",
        meta: "Optional snow/meadow walk · Alt: 2,850m · Breakfast & Farewell Dinner",
        detail: "Wake to uninterrupted views of Dhauladhar snow crests. Enjoy a private warm thermos picnic in a quiet alpine clearing, followed by an intimate lantern-lit farewell dinner."
      },
      {
        day: "Day 6",
        title: "Unhurried Mountain Morning & Departure Transfer",
        meta: "Check-out 11:00 AM · Private Airport Drop · Breakfast",
        detail: "Savour fresh sourdough and orchard preserves on the sun deck before your private transfer back to Bhuntar or Chandigarh with artisan Kullu wool keepsakes."
      }
    ],
    faqs: [
      {
        q: "Are there any hidden charges or extra local union cab costs in Manali?",
        a: "Zero hidden charges. Where local Himachal taxi rules require snow-4x4 vehicles for Sethan during heavy snowfall, our package already covers the 4x4 transfer cost upfront."
      },
      {
        q: "Is Sethan comfortable for couples or seniors in December–February?",
        a: "Yes. Every room we use has heavy-insulation glazing, heated mattresses, and traditional wood stoves, plus 24-hour power backup."
      },
      {
        q: "Can we customize dates for our honeymoon?",
        a: "Every journey can depart privately on your exact wedding/travel dates at no extra private-departure surcharge for 2+ guests."
      }
    ]
  },
  {
    id: "pkg-kerala",
    slug: "kerala-backwater-escape",
    seoTitle: "Kerala Private Backwaters & Marari Beach Slow Escape (5 Days) | Aranya Journeys",
    seoDescription: "5-day luxury Kumarakom & Marari beach retreat with private wooden kettuvallam cruise, heritage spice bungalow, and transparent pricing.",
    title: "Kumarakom & Marari Backwater Slow-Cruise",
    location: "Kerala · Vembanad Lake & Marari Coast",
    duration: "4 Nights · 5 Days",
    price: 54000,
    rating: "4.9",
    reviewCount: 119,
    badge: "Bestseller",
    secondaryBadge: "Eco Stay",
    categories: ["beach", "family", "honeymoon", "eco"],
    urgency: "Only 3 cabins left for 18 Dec batch",
    batches: ["18 Dec – 22 Dec", "26 Dec – 30 Dec", "08 Jan – 12 Jan", "22 Jan – 26 Jan"],
    heroImage: "assets/images/pkg-kerala.jpg",
    gallery: [
      "assets/images/pkg-kerala.jpg",
      "assets/images/pkg-coorg.jpg"
    ],
    summaryLine: "Private 1-bedroom wooden Kettuvallam · Beachfront heritage villa · Personal chef · Kochi transfers",
    overview: "Trade crowded Alleppey boat jetties for quiet Kumarakom canals and the palm-shaded sands of Mararikulam. Includes an exclusive single-suite handcrafted wooden houseboat with your own private chef and two coastal nights by the Arabian Sea.",
    priceBreakup: [
      { label: "3 Nights Heritage Villa + 1 Night Private Luxury Kettuvallam", amount: 33400 },
      { label: "Private Chauffeur Sedan/SUV from Cochin Airport (COK)", amount: 7800 },
      { label: "All Meals on Houseboat, Daily Breakfasts & Toddy-Shop Seafood Tasting", amount: 10200 },
      { label: "Village Canoe Excursion, Port Taxes & 5% GST", amount: 2600 }
    ],
    inclusions: [
      "2 nights lakefront heritage bungalow in Kumarakom",
      "1 night exclusive private wooden Kettuvallam (never shared) with dedicated captain & chef",
      "1 night coastal eco-villa steps from quiet Marari beach",
      "Dawn narrow-canal shikara & country canoe birding paddle",
      "Cochin Airport pickup/drop, all boat mooring fees & 5% GST"
    ],
    exclusions: [
      "Airfare to/from Cochin International Airport (COK)",
      "Optional Ayurvedic abhyanga therapies at resort spa"
    ],
    itinerary: [
      { day: "Day 1", title: "Cochin Arrival to Kumarakom Lake Sanctuary", meta: "Drive: 1 hr 45 min · Lakefront Check-in", detail: "Arrive at Cochin and glide south to a restored 1920s timbertharavad set directly on Vembanad Lake. Sunset flute recital on the jetty." },
      { day: "Day 2", title: "Dawn Country Canoe & Spice Homestead Lunch", meta: "Narrow canal exploration · Breakfast & Lunch", detail: "Slip silently into narrow lotus-lined canals unreachable by motorboats, visiting toddy tappers and a family-run nutmeg homestead." },
      { day: "Day 3", title: "Board Your Private Handcrafted Kettuvallam", meta: "Private Cruise · All Meals by Personal Chef", detail: "Step aboard your private jackwood houseboat at noon. Watch emerald rice paddies drift past at 6 knots while your chef prepares fresh karimeen pollichathu." },
      { day: "Day 4", title: "Disembark to Quiet Marari Fisherman's Coast", meta: "35 min drive · Beachfront Villa", detail: "Trade still backwaters for four kilometres of empty golden sand shaded by coconut groves at Mararikulam." },
      { day: "Day 5", title: "Fort Kochi Heritage Stroll & Airport Drop", meta: "Optional heritage walk · Departure", detail: "Stop at Jew Town and Chinese fishing nets in Fort Kochi if flight timings allow, before smooth Cochin Airport drop-off." }
    ],
    faqs: [
      { q: "Does the houseboat keep cruising at night or dock safely?", a: "Per Kerala maritime eco-norms and for completely peaceful sleep without engine vibration, boats anchor in a quiet private lagoon from 5:30 PM to 7:30 AM with full AC." },
      { q: "Is vegetarian / Jain food freshly prepared onboard?", a: "Yes—because the boat and kitchen are 100% private to your party, our chef shops fresh that morning to your exact dietary preferences." }
    ]
  },
  {
    id: "pkg-andaman",
    slug: "andaman-private-island-retreat",
    seoTitle: "Andaman Secluded Reef & Havelock Luxury Package (6 Days) | Aranya Journeys",
    seoDescription: "6-day Havelock & Neil Island private coastal sanctuary with luxury catamaran ferries, forest-edge beach villas, and private guided reef snorkelling.",
    title: "Havelock & Neil Untouched Reef Sanctuary",
    location: "Andaman Islands · Swaraj & Shaheed Dweep",
    duration: "5 Nights · 6 Days",
    price: 62500,
    rating: "4.9",
    reviewCount: 94,
    badge: "Limited Seats",
    secondaryBadge: "4.9 Rated",
    categories: ["beach", "honeymoon", "family"],
    urgency: "Only 4 seats left for 22 Dec batch",
    batches: ["22 Dec – 27 Dec", "03 Jan – 08 Jan", "15 Jan – 20 Jan", "05 Feb – 10 Feb"],
    heroImage: "assets/images/pkg-andaman.jpg",
    gallery: [
      "assets/images/pkg-andaman.jpg",
      "assets/images/pkg-kerala.jpg"
    ],
    summaryLine: "Rainforest beach villas · Royal Class Catamaran · Private boat snorkelling · Island transfers",
    overview: "Experience the Andamans the way they felt twenty years ago—early-dawn reef charters before day-trippers arrive, bioluminescent night kayaking through mangroves, and barefoot villas hidden under mahua trees.",
    priceBreakup: [
      { label: "5 Nights Boutique Rainforest-Beach Villas (Havelock & Neil)", amount: 39800 },
      { label: "Royal Class High-Speed Catamaran Tickets & Private Island Cars", amount: 10400 },
      { label: "Private Sunrise Snorkelling Charter, Night Kayaking & Breakfasts", amount: 9300 },
      { label: "Marine Park Permits & 5% GST", amount: 3000 }
    ],
    inclusions: [
      "3 nights beachfront forest villa on Havelock + 1 night quiet Neil Island + 1 night Port Blair boutique stay",
      "Royal-class Makruzz / Nautika inter-island catamaran seats",
      "Sunrise private boat charter to secluded coral gardens with PADI-certified reef guide",
      "Guided night bioluminescence kayaking in Havelock mangroves",
      "Dedicated point-to-point island transfers (zero waiting at jetties) & 5% GST"
    ],
    exclusions: [
      "Flights to Port Blair (IXZ)",
      "Optional scuba discovery dive (₹4,200 pre-bookable with our PADI partner)"
    ],
    itinerary: [
      { day: "Day 1", title: "Port Blair Arrival & Catamaran to Havelock Island", meta: "90 min Royal Catamaran · Beach Check-in", detail: "Meet our island coordinator right outside Veer Savarkar Airport and sail across turquoise channels to Swaraj Dweep (Havelock)." },
      { day: "Day 2", title: "6:00 AM Private Reef Snorkelling & Radhanagar Sunset", meta: "Private Boat · Breakfast Included", detail: "Reach pristine coral walls an hour before public boats operate. Evening barefoot walk along Asia's finest crescent beach at Radhanagar." },
      { day: "Day 3", title: "Kalapathar Forest Trail & Bioluminescence Kayaking", meta: "Guided Night Paddle · Breakfast & Dinner", detail: "Unhurried coastal morning, followed by a magical new-moon/dark-water kayak watching glowing marine phytoplankton swirl under your paddle." },
      { day: "Day 4", title: "Sail to Unhurried Neil Island (Shaheed Dweep)", meta: "45 min ferry · Coral Bridge Walk", detail: "Cross to tiny, cycling-paced Neil Island. Explore living tide pools at Natural Rock Bridge with a marine naturalist at low tide." },
      { day: "Day 5", title: "Return to Port Blair & Chidiya Tapu Sunset", meta: "Afternoon Ferry · Forest Headland", detail: "Return to South Andaman and watch the sun dip behind Rutland Island from quiet Chidiya Tapu." },
      { day: "Day 6", title: "Morning Departure from Port Blair", meta: "15 min Airport Drop · Breakfast", detail: "Smooth transfer for your morning mainland flight." }
    ],
    faqs: [
      { q: "Do Indian citizens need a visa or Inner Line Permit for Havelock & Neil?", a: "Indian citizens do NOT need a visa or RAP permit for Port Blair, Havelock, or Neil Island—only a valid government photo ID." },
      { q: "How is mobile network & Wi-Fi on Havelock?", a: "Airtel and Jio 4G/5G now work reliably in Havelock and Port Blair, and all our partner villas provide fiber Wi-Fi." }
    ]
  },
  {
    id: "pkg-ladakh",
    slug: "ladakh-silent-valleys-expedition",
    seoTitle: "Ladakh Silent Valleys: Leh, Nubra, Turtuk & Pangong (7 Days) | Aranya Journeys",
    seoDescription: "Acclimatisation-first 7-day private Ladakh journey covering Leh, Turtuk apricot village, Nubra & Pangong with supplemental oxygen and heritage stays.",
    title: "Ladakh Silent Valleys & Turtuk",
    location: "Ladakh · Leh, Nubra, Turtuk & Pangong",
    duration: "6 Nights · 7 Days",
    price: 68000,
    rating: "5.0",
    reviewCount: 87,
    badge: "New",
    secondaryBadge: "5.0 Rated",
    categories: ["mountains", "family"],
    urgency: "6 seats open for Spring batch",
    batches: ["10 Apr – 16 Apr", "24 Apr – 30 Apr", "09 May – 15 May", "23 May – 29 May"],
    heroImage: "assets/images/pkg-ladakh.jpg",
    gallery: [
      "assets/images/pkg-ladakh.jpg",
      "assets/images/hero-himalayas.jpg"
    ],
    summaryLine: "Restored Ladakhi heritage homes · Private Innova Crysta · Onboard oxygen · Inner Line Permits",
    overview: "Built around medically sound altitude acclimatisation and quiet cultural immersion—staying in apricot-orchard family estates in Nimmu and Turtuk rather than noisy canvas camp rows.",
    priceBreakup: [
      { label: "6 Nights Boutique Heritage Houses & Heated Pangong Villa", amount: 41500 },
      { label: "Private Ladakhi-Owned Innova Crysta Across High Passes", amount: 15800 },
      { label: "Daily Breakfasts, Home-Cooked Dinners & Monastery Scholar Walk", amount: 7460 },
      { label: "Inner Line Permits, Portable Oxygen Cylinder & 5% GST", amount: 3240 }
    ],
    inclusions: [
      "6 nights in characterful Ladakhi mud-brick & poplar-wood boutique estates",
      "Private local Innova Crysta with veteran high-pass Ladakhi driver",
      "Portable medical oxygen cylinder & pulse oximeter carried in vehicle throughout",
      "All Inner Line Permits for Nubra, Turtuk & Pangong Lake",
      "Breakfasts & warm Ladakhi/continental dinners daily & 5% GST"
    ],
    exclusions: [
      "Flights to Kushok Bakula Rimpochee Airport, Leh (IXL)",
      "Monastery camera fees where applicable"
    ],
    itinerary: [
      { day: "Day 1", title: "Arrival in Leh & Complete Acclimatisation Rest", meta: "Alt: 3,500m · Gentle Orchard Rest", detail: "Airport pickup to a quiet poplar-shaded boutique estate in Leh. Complete rest, butter tea, and hydration monitoring." },
      { day: "Day 2", title: "Thiksey Morning Chant & Indus Confluence", meta: "Alt: 3,500m · Scholar-led Walk", detail: "Attend sunrise prayers at Thiksey Monastery before visitors arrive, followed by Alchi's 1,000-year-old Kashmiri frescoes." },
      { day: "Day 3", title: "Across Khardung La to Nubra's Kyagar Oasis", meta: "Drive: 4.5 hrs · Nubra Valley", detail: "Cross into the Shyok river valley and unwind in an oasis garden framed by Karakoram granite walls." },
      { day: "Day 4", title: "Balti Heritage Day in Turtuk Apricot Village", meta: "Borderland Cultural Walk · Lunch Included", detail: "Walk stone irrigation channels and centuries-old walnut groves in India's northernmost Balti village." },
      { day: "Day 5", title: "Shyok River Route to Quiet Merak Shore, Pangong", meta: "Scenic Valley Drive · Alt: 4,250m", detail: "Bypass crowded Spangmik tents for a heated stone cottage in quiet Merak village right above sapphire Pangong Tso." },
      { day: "Day 6", title: "Sunrise by the Glacial Lake & Return to Leh", meta: "Drive via Chang La · Farewell Dinner", detail: "Watch golden dawn paint the lake in seven shades of blue before returning to warm beds in Leh." },
      { day: "Day 7", title: "Morning Flight Over the Himalayan Crest", meta: "15 min Airport Drop · Breakfast", detail: "Transfer to Leh Airport (tip: pick window seat A for K2 & Nun-Kun views!)." }
    ],
    faqs: [
      { q: "How do you manage Acute Mountain Sickness (AMS)?", a: "We never rush you over Khardung La before 48 hours at Leh/Indus elevation, check SpO2 daily, and carry medical oxygen in every vehicle." }
    ]
  },
  {
    id: "pkg-coorg",
    slug: "coorg-rainforest-eco-stay",
    seoTitle: "Coorg Rainforest & Single-Estate Coffee Retreat (4 Days) | Aranya Journeys",
    seoDescription: "4-day Western Ghats eco-luxury coffee estate sanctuary in Coorg with private Bengaluru/Mysuru transfers, bean-to-cup tasting, and Kodava dining.",
    title: "Coorg Misty Rainforest & Estate",
    location: "Karnataka · Southern Coorg & Brahmagiri",
    duration: "3 Nights · 4 Days",
    price: 36500,
    rating: "4.9",
    reviewCount: 112,
    badge: "Eco Stay",
    secondaryBadge: "4.9 Rated",
    categories: ["mountains", "eco", "family", "honeymoon"],
    urgency: "Only 2 villas left for 14 Dec weekend",
    batches: ["14 Dec – 17 Dec", "21 Dec – 24 Dec", "04 Jan – 07 Jan", "18 Jan – 21 Jan"],
    heroImage: "assets/images/pkg-coorg.jpg",
    gallery: [
      "assets/images/pkg-coorg.jpg",
      "assets/images/pkg-kerala.jpg"
    ],
    summaryLine: "120-acre shade-grown coffee estate · Private car from Bengaluru · Kodava estate dining",
    overview: "Just five scenic hours from Bengaluru, disappear into a 120-acre shade-grown Arabica and black-pepper sanctuary bordering the Brahmagiri wildlife corridor. Zero concrete resorts—only teak verandas, birdsong, and silver mountain mist.",
    priceBreakup: [
      { label: "3 Nights Plantation Veranda Suite inside Private 120-Acre Estate", amount: 22800 },
      { label: "Private Chauffeur Car Pickup & Drop from Bengaluru / Mysuru", amount: 7200 },
      { label: "Daily Breakfasts, Heirloom Kodava Dinners & Estate Coffee Roasting", amount: 4760 },
      { label: "Rainforest Stream Walk & 5% GST", amount: 1740 }
    ],
    inclusions: [
      "3 nights in an elevated teakwood plantation suite with private rain-shower deck",
      "Door-to-door private SUV/sedan from your Bengaluru home or airport",
      "Private bean-to-cup specialty coffee cupping with third-generation planter",
      "Heirloom Kodava candlelit dinner & morning birding walk",
      "All tolls, driver allowances & 5% GST"
    ],
    exclusions: [
      "Flights to Bengaluru (BLR) if arriving from outside Karnataka",
      "Nagarhole safari jeep fee if added as optional Day 3 excursion"
    ],
    itinerary: [
      { day: "Day 1", title: "Bengaluru to Southern Coorg via Mysuru", meta: "Drive: 5 hrs · Estate Welcome", detail: "Doorstep pickup in Bengaluru. Arrive by afternoon to freshly brewed estate pour-over and mist rolling across the Western Ghats." },
      { day: "Day 2", title: "Rainforest Stream Trail & Planter's Tasting Table", meta: "Private 120-acre trail · Breakfast & Dinner", detail: "Walk shaded cardamom and pepper vines down to a private mountain stream, followed by single-estate coffee roasting." },
      { day: "Day 3", title: "Slow Veranda Reading Day or Nagarhole Forest Drive", meta: "Unhurried pace · Kodava Feast", detail: "Spend the day reading in linen hammocks or take an optional morning drive along the Kabini/Nagarhole forest edge." },
      { day: "Day 4", title: "Estate Brunch & Return to Bengaluru", meta: "Check-out Noon · Home Drop", detail: "Carry home freshly roasted estate beans on your smooth drive back to Bengaluru." }
    ],
    faqs: [
      { q: "Is this suitable for a toddler or elderly parents?", a: "Exceptionally so—Southern Coorg sits at a gentle 1,100m altitude with mild weather year-round and step-free ground-floor veranda suites available." }
    ]
  },
  {
    id: "pkg-udaipur",
    slug: "udaipur-jawai-heritage-retreat",
    seoTitle: "Udaipur Lakefront & Jawai Granite Hills Retreat (5 Days) | Aranya Journeys",
    seoDescription: "5-day understated Rajasthan luxury pairing a quiet Lake Pichola sandstone haveli with Jawai's granite leopard hills and private 4x4 safaris.",
    title: "Udaipur & Jawai Sandstone Sanctuary",
    location: "Rajasthan · Lake Pichola & Jawai Hills",
    duration: "4 Nights · 5 Days",
    price: 58500,
    rating: "4.9",
    reviewCount: 82,
    badge: "Limited Seats",
    secondaryBadge: "4.9 Rated",
    categories: ["honeymoon", "family"],
    urgency: "Only 4 suites left for 20 Dec batch",
    batches: ["20 Dec – 24 Dec", "28 Dec – 01 Jan", "10 Jan – 14 Jan", "24 Jan – 28 Jan"],
    heroImage: "assets/images/pkg-udaipur.jpg",
    gallery: [
      "assets/images/pkg-udaipur.jpg",
      "assets/images/traveler-chai.jpg"
    ],
    summaryLine: "Lakefront sandstone haveli · Jawai wilderness camp · Private 4x4 leopard tracking · Boat sunset",
    overview: "Skip rushed 5-city Rajasthan bus loops. Pair two lyrical nights in a quiet carved-sandstone courtyard on Lake Pichola with two nights among Jawai's billion-year-old granite domes where leopards and Rabari shepherds coexist.",
    priceBreakup: [
      { label: "2 Nights Lakefront Boutique Haveli + 2 Nights Jawai Wilderness Suite", amount: 38200 },
      { label: "Private Chauffeur Car + Exclusive Private 4x4 Jawai Gypsy Tracker", amount: 11400 },
      { label: "Private Wooden Boat Cruise, Bush Sundowner & Daily Breakfast/Dinners", amount: 6115 },
      { label: "Heritage Conservation Fees & 5% GST", amount: 2785 }
    ],
    inclusions: [
      "2 nights lake-facing suite in an intimate 18-room Udaipur sandstone haveli",
      "2 nights luxury stone-and-canvas wilderness suite in Jawai",
      "Private sunrise wooden shikara ride on quiet Lake Pichola",
      "1 exclusive private 4x4 Jawai leopard & birding drive with Rabari tracker",
      "Udaipur Airport (UDR) transfers, breakfasts, 3 curated dinners & 5% GST"
    ],
    exclusions: [
      "Flights to Maharana Pratap Airport, Udaipur (UDR)",
      "Monument entry tickets if opting for City Palace guided museum walk"
    ],
    itinerary: [
      { day: "Day 1", title: "Udaipur Arrival & Private Sunset Wooden Boat", meta: "35 min from Airport · Lake Pichola", detail: "Check into a tranquil lime-plaster courtyard right on the water. Glide out at dusk in a private wooden boat away from motor launches." },
      { day: "Day 2", title: "Old City Craft Lanes & Delwara Stepwell Morning", meta: "Guided Architecture Walk · Breakfast", detail: "Walk early-morning marble lanes visiting miniature painters and quiet Aravalli stepwells before returning to your lake terrace." },
      { day: "Day 3", title: "Aravalli Drive via Ranakpur Marble Temple to Jawai", meta: "Drive: 3 hrs · Granite Wilderness", detail: "Marvel at Ranakpur's 1,444 hand-carved marble pillars en route to the dramatic granite boulders of Jawai." },
      { day: "Day 4", title: "Dawn Private 4x4 Leopard Tracking & Dam Sundowner", meta: "Private Gypsy · All Meals", detail: "Track elusive Indian leopards basking on sunlit granite tors alongside flamingos and Sarus cranes by Jawai Bandh." },
      { day: "Day 5", title: "Morning Bush Breakfast & Udaipur Airport Drop", meta: "2.5 hr smooth drive · Departure", detail: "Enjoy hot masala chai overlooking the hills before returning smoothly to Udaipur Airport." }
    ],
    faqs: [
      { q: "Are Jawai safaris crowded like Ranthambore?", a: "Not at all. Jawai is a community-conserved granite landscape where we use private 4x4 trackers with no chaotic vehicle queues." }
    ]
  }
];

const VERIFIED_REVIEWS = [
  {
    id: "rev-1",
    name: "Ananya Deshmukh",
    city: "Mumbai",
    photo: "assets/images/reviewer-ananya.jpg",
    trip: "Manali & Sethan Deodar Sanctuary",
    date: "November 2026",
    rating: 5,
    quote: "Every travel company promises 'offbeat', then puts you in a noisy hotel near Mall Road. Aranya put us in a six-room cedar house in Sethan where the only sound at 7 AM was snow sliding off pine branches. Not one rupee asked beyond the quote."
  },
  {
    id: "rev-2",
    name: "Vikramaditya & Rohini Rao",
    city: "Bengaluru",
    photo: "assets/images/reviewer-vikram.jpg",
    trip: "Kumarakom & Marari Backwater Slow-Cruise",
    date: "October 2026",
    rating: 5,
    quote: "We travelled with my 72-year-old parents and our 6-year-old daughter. Priya called twice before departure just to note my father's low-sodium meals. Having a completely private wooden kettuvallam with our own chef felt deeply restorative."
  },
  {
    id: "rev-3",
    name: "Siddharth & Meera Kulkarni",
    city: "Pune",
    photo: "assets/images/traveler-chai.jpg",
    trip: "Ladakh Silent Valleys & Turtuk",
    date: "September 2026",
    rating: 5,
    quote: "Their insistence on two slow acclimatisation nights saved our trip. While other tourists had headaches at Pangong, we stayed in a heated stone cottage in quiet Merak with pulse oximeters and warm soup waiting. Worth every rupee."
  },
  {
    id: "rev-4",
    name: "Dr. Kavita Subramanian",
    city: "Chennai",
    photo: "assets/images/curator-priya.jpg",
    trip: "Havelock & Neil Untouched Reef Sanctuary",
    date: "October 2026",
    rating: 5,
    quote: "Going out on a private snorkelling boat at 6:00 AM meant we had an entire coral garden to ourselves for ninety minutes before a single ferry arrived. Seamless jetty handoffs—never waited even five minutes."
  },
  {
    id: "rev-5",
    name: "Rohan & Devika Malhotra",
    city: "New Delhi",
    photo: "assets/images/founder-aarav.jpg",
    trip: "Udaipur & Jawai Sandstone Sanctuary",
    date: "August 2026",
    rating: 5,
    quote: "Transparent line-by-line pricing won us over before we even spoke. When my flight was delayed by a storm, Aarav's Udaipur team rescheduled our private boat ride to the next dawn without charging a penalty."
  },
  {
    id: "rev-6",
    name: "Nikhil & Shruti Verma",
    city: "Hyderabad",
    photo: "assets/images/reviewer-vikram.jpg",
    trip: "Coorg Misty Rainforest & Estate",
    date: "July 2026",
    rating: 5,
    quote: "Three nights inside a 120-acre coffee estate during the misty Western Ghats monsoon reset six months of burnout. Honest drive times, spotless SUV, and heirloom Kodava food we still talk about."
  }
];

const TRAVEL_GUIDES = [
  {
    slug: "best-time-to-visit-india-calendar",
    category: "Best Time to Visit",
    readTime: "6 min read",
    updated: "Updated November 2026",
    title: "When to Go Where: An Honest Month-by-Month Calendar for Mountains & Coasts",
    excerpt: "Skip peak school-holiday gridlock. Here is when Manali has quiet powder snow, when Andaman water visibility hits 25 metres, and why shoulder weeks feel twice as luxurious.",
    image: "assets/images/hero-himalayas.jpg",
    relatedPackageSlug: "manali-honeymoon-package",
    sections: [
      {
        heading: "October to Mid-December: Crisp Alpine Skies & Quiet Coasts",
        body: "Post-monsoon air scrubs haze from the Pir Panjal and Dhauladhar ranges. Old Manali and Sethan enjoy golden daytime sunshine (14°C) and crisp starry nights (2°C) before New Year highway traffic begins. Down south, Kumarakom's backwaters brim with fresh emerald water."
      },
      {
        heading: "January to March: Fresh Himalayan Snow & Glass-Calm Andaman Seas",
        body: "For couples dreaming of snow-draped deodars, mid-January to late February in Sethan and Hampta delivers deep snow without December surcharges. Simultaneously, Havelock and Neil Islands see mirror-calm seas with 20–25m underwater reef visibility."
      },
      {
        heading: "April to June: Ladakh Apricot Blossoms & High-Altitude Solitude",
        body: "Late April brings pale pink apricot blossoms across Turtuk and Sham Valley in Ladakh—weeks before summer convoy season starts. In the Western Ghats, pre-monsoon showers perfume Coorg's coffee blossoms."
      },
      {
        heading: "July to September: Monsoon Rainforests & Rain-Shadow Ladakh",
        body: "While coastal beaches rest, Ladakh sits in the Trans-Himalayan rain shadow with warm blue skies, and Coorg's private rainforest estates turn into an emerald sanctuary for slow readers."
      }
    ]
  },
  {
    slug: "permits-and-visa-guide-travellers",
    category: "Visa & Permits Guide",
    readTime: "5 min read",
    updated: "Updated November 2026",
    title: "The Stress-Free Inner Line Permit (ILP) & Travel Document Guide",
    excerpt: "Everything Indian & NRI/OCI travellers need to know about Ladakh Inner Line Permits, Himachal Rohtang/Sethan winter passes, Andaman island rules, and neighboring Bhutan/Sri Lanka e-Visas.",
    image: "assets/images/pkg-ladakh.jpg",
    relatedPackageSlug: "ladakh-silent-valleys-expedition",
    sections: [
      {
        heading: "1. Ladakh (Nubra, Turtuk, Pangong & Hanle)",
        body: "Indian citizens require an Environmental & Inner Line Permit, which Aranya files online 72 hours prior using your Aadhaar or Passport. OCI/foreign passport holders require a Protected Area Permit (PAP) issued in Leh—we handle all paperwork on Day 1 while you acclimatise."
      },
      {
        heading: "2. Himachal Pradesh (Sethan, Hampta & Atal Tunnel Corridors)",
        body: "Sethan village sits inside a sensitive winter eco-zone. Entry permits and snow-4x4 local union clearances are pre-arranged by our Old Manali field office so you never queue at checkposts."
      },
      {
        heading: "3. Andaman Islands (Havelock, Neil & Marine Parks)",
        body: "Indian citizens need zero special permits for Port Blair, Swaraj Dweep (Havelock), and Shaheed Dweep (Neil). Carry original Aadhaar/Voter ID/Passport, as DigiLocker screenshots are occasionally declined at jetty security."
      },
      {
        heading: "4. Combining India with Bhutan or Sri Lanka",
        body: "Indian passport holders enjoy visa-free entry to Bhutan (with ₹1,200/night Sustainable Development Fee & Voter ID/Passport with 6+ months validity) and instant ETA authorization for Sri Lanka."
      }
    ]
  },
  {
    slug: "minimalist-packing-list-mountains-coast",
    category: "Packing List",
    readTime: "4 min read",
    updated: "Updated November 2026",
    title: "The One-Suitcase Packing List: Layering for -2°C Pines or 28°C Backwaters",
    excerpt: "Overpacking kills calm travel. Use our field-tested 3-layer system for Himalayan winters and breathable natural-fibre checklist for coastal escapes.",
    image: "assets/images/pkg-coorg.jpg",
    relatedPackageSlug: "coorg-rainforest-eco-stay",
    sections: [
      {
        heading: "The Himalayan 3-Layer Rule (Manali & Ladakh)",
        body: "Instead of one bulky coat, pack: (1) Merino or Uniqlo Heattech base layer next to skin, (2) Medium fleece or cashmere mid-layer, and (3) Packable windproof down jacket. Add wool socks, waterproof ankle-grip shoes, lip balm, and UV400 sunglasses for snow glare."
      },
      {
        heading: "Coastal & Rainforest Essentials (Kerala, Andaman & Coorg)",
        body: "Stick to breathable flax linen, light cottons, reef-safe mineral sunscreen (chemical sunscreens bleach Andaman coral), slip-on sandals for jetty boarding, and a compact dry-bag for phone & camera."
      },
      {
        heading: "Documents, Health & Tech Kit",
        body: "Original government photo ID (not just photocopy), personal prescription medicines, ORS sachets, 10,000mAh power bank (cold drains batteries 30% faster in mountains), and BSNL/Airtel postpaid SIM if visiting Ladakh."
      }
    ]
  }
];

const PACKING_CHECKLIST_ITEMS = [
  "Original Government Photo ID (Passport / Aadhaar / Voter ID) for all travellers",
  "Breathable thermal base layer + fleece mid-layer + packable down jacket (Mountain trips)",
  "Broken-in walking shoes with grippy soles + 3 pairs warm wool/cotton socks",
  "UV400 sunglasses, SPF 50 reef-safe sunscreen & hydrating lip balm",
  "Personal prescription kit, motion-comfort tablets & ORS hydration sachets",
  "10,000mAh power bank (in cabin bag) & universal multi-port charger",
  "Reusable insulated steel flask (all Aranya vehicles carry filtered drinking water jars)"
];

/* CMS Helpers — Add/Edit/Reset Packages Without Touching Code */
function getPackages() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [...DEFAULT_PACKAGES];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : [...DEFAULT_PACKAGES];
  } catch {
    return [...DEFAULT_PACKAGES];
  }
}

function savePackages(list) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

function resetPackagesToDefault() {
  localStorage.removeItem(STORAGE_KEY);
  return [...DEFAULT_PACKAGES];
}

function formatINR(amount) {
  return "₹" + Number(amount || 0).toLocaleString("en-IN");
}

window.AranyaData = {
  BUSINESS_CREDENTIALS,
  DEFAULT_PACKAGES,
  VERIFIED_REVIEWS,
  TRAVEL_GUIDES,
  PACKING_CHECKLIST_ITEMS,
  getPackages,
  savePackages,
  resetPackagesToDefault,
  formatINR
};
