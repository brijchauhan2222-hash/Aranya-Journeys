/* ==========================================================================
   ARANYA JOURNEYS — APPLICATION ROUTER, BOOKING ENGINE & SIMPLE CMS
   ========================================================================== */

const {
  BUSINESS_CREDENTIALS,
  VERIFIED_REVIEWS,
  TRAVEL_GUIDES,
  PACKING_CHECKLIST_ITEMS,
  getPackages,
  savePackages,
  resetPackagesToDefault,
  formatINR
} = window.AranyaData;

const state = {
  searchDestination: "all",
  searchMonth: "December 2026",
  searchTravellers: 2,
  activeCategory: "all",
  lastBooking: null,
  packingChecked: {}
};

const appMain = document.getElementById("app-main");
const siteHeader = document.getElementById("site-header");
const waFloatBtn = document.getElementById("whatsapp-floating-btn");
const mobileBar = document.getElementById("mobile-booking-bar");
const mobileBarPrice = document.getElementById("mobile-bar-price");
const mobileBarSub = document.getElementById("mobile-bar-sub");
const mobileBarCta = document.getElementById("mobile-bar-cta");
const modalRoot = document.getElementById("modal-root");

/* Escape helper */
function esc(str) {
  return String(str ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function buildWhatsAppUrl(message) {
  return `https://wa.me/${BUSINESS_CREDENTIALS.phoneRaw}?text=${encodeURIComponent(message)}`;
}

function updateSEO(title, description) {
  document.title = title;
  const metaDesc = document.getElementById("meta-description");
  if (metaDesc && description) {
    metaDesc.setAttribute("content", description);
  }
}

function updateHeaderGlassMode(isHeroPhotoPage) {
  const scrolled = window.scrollY > 80;
  if (isHeroPhotoPage && !scrolled) {
    siteHeader.classList.add("over-photo");
    siteHeader.classList.remove("scrolled-solid");
  } else {
    siteHeader.classList.remove("over-photo");
    siteHeader.classList.add("scrolled-solid");
  }
}

function updateActiveNav(routeKey) {
  document.querySelectorAll(".nav-link").forEach((link) => {
    link.classList.toggle("active", link.dataset.route === routeKey);
  });
  siteHeader.classList.remove("menu-open");
}

function setWhatsAppContext(labelText, prefilledMsg) {
  if (!waFloatBtn) return;
  waFloatBtn.href = buildWhatsAppUrl(prefilledMsg);
  const labelSpan = waFloatBtn.querySelector(".wa-label");
  if (labelSpan) labelSpan.textContent = labelText;
}

function setMobileBookingBar(pkg) {
  if (!pkg) {
    mobileBar.classList.remove("is-active");
    document.body.classList.remove("has-mobile-bar");
    return;
  }
  mobileBarPrice.textContent = `${formatINR(pkg.price)} / person`;
  mobileBarSub.textContent = pkg.urgency;
  mobileBar.classList.add("is-active");
  document.body.classList.add("has-mobile-bar");
  mobileBarCta.onclick = () => {
    const widget = document.getElementById("booking-widget-card");
    if (widget) widget.scrollIntoView({ behavior: "smooth", block: "start" });
  };
}

/* Reusable Package Card Component (With iOS Glass Badges & Floating Price Card) */
function renderPackageCard(pkg) {
  return `
    <article class="package-card" data-pkg-slug="${esc(pkg.slug)}" tabindex="0" role="link" aria-label="${esc(pkg.title)}">
      <div class="package-media">
        <img src="${esc(pkg.heroImage)}" alt="${esc(pkg.title)} — ${esc(pkg.location)}" loading="lazy" width="640" height="480" />
        <div class="media-top-badges">
          <span class="glass-badge">${esc(pkg.badge)}</span>
          <span class="glass-badge"><span class="gold-star">★</span> ${esc(pkg.rating)} Rated</span>
        </div>
        <div class="floating-price-glass">
          <span class="price-amount">${formatINR(pkg.price)}</span>
          <span class="price-unit">per person · all incl.</span>
        </div>
      </div>
      <div class="package-body">
        <div class="package-meta-line tabular">
          <span>${esc(pkg.location)}</span>
          <span>${esc(pkg.duration)}</span>
        </div>
        <h3 class="package-title">${esc(pkg.title)}</h3>
        <p class="package-inclusions-line">${esc(pkg.summaryLine)}</p>
        <div class="package-card-footer">
          <span class="urgency-note">${esc(pkg.urgency)}</span>
          <span class="card-cta-text">Itinerary →</span>
        </div>
      </div>
    </article>
  `;
}

function bindPackageCardClicks(root = appMain) {
  root.querySelectorAll(".package-card[data-pkg-slug]").forEach((card) => {
    const go = () => {
      window.location.hash = `#/package/${card.dataset.pkgSlug}`;
    };
    card.addEventListener("click", go);
    card.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        go();
      }
    });
  });
}

/* ==========================================================================
   PAGE 1: HOME — Make Them Stay (Hero Search, 6 Curated Trips, Why Us, Reviews)
   ========================================================================== */
function renderHome() {
  const allPackages = getPackages();
  const curatedSix = allPackages.slice(0, 6); // Strictly 6 curated packages on Home

  updateSEO(
    "Aranya Journeys — Quiet Luxury & Bespoke Private Travel Across India",
    "Hand-inspected boutique eco-stays, private chauffeurs, and 100% transparent line-item pricing across Manali, Kerala, Andaman, Ladakh, Coorg & Udaipur."
  );
  updateActiveNav("home");
  setMobileBookingBar(null);
  setWhatsAppContext("WhatsApp Priya · Plan Manali", "Hi, I want to plan a trip to Manali.");

  appMain.innerHTML = `
    <!-- FULL-BLEED HERO PHOTO + iOS GLASS SEARCH BAR -->
    <section class="hero-section">
      <img
        src="assets/images/hero-himalayas.jpg"
        alt="Vast misty Himalayan cedar valley at golden morning light with tiny distant trekkers on a quiet ridge path"
        class="hero-bg-img"
        fetchpriority="high"
      />
      <div class="hero-scrim"></div>

      <div class="container hero-content">
        <div class="hero-copy">
          <h1>Travel slow enough to hear the mountains breathe.</h1>
          <p>
            Private, unhurried journeys across India’s quietest sanctuaries. Hand-inspected stays, dedicated chauffeurs, and every single rupee explained before you book.
          </p>
        </div>

        <!-- 2. SEARCH BAR IN SINGLE-LAYER iOS GLASS -->
        <form id="hero-search-form" class="hero-search-bar ios-glass" aria-label="Search Curated Journeys">
          <div class="search-field">
            <label for="hero-dest-select">Destination</label>
            <select id="hero-dest-select" name="destination">
              <option value="all">Anywhere Quiet in India</option>
              <option value="manali-honeymoon-package">Manali &amp; Sethan Sanctuary</option>
              <option value="kerala-backwater-escape">Kerala Backwaters &amp; Marari</option>
              <option value="andaman-private-island-retreat">Andaman Untouched Reefs</option>
              <option value="ladakh-silent-valleys-expedition">Ladakh &amp; Turtuk Valleys</option>
              <option value="coorg-rainforest-eco-stay">Coorg Rainforest Estate</option>
              <option value="udaipur-jawai-heritage-retreat">Udaipur &amp; Jawai Hills</option>
            </select>
          </div>

          <div class="search-field">
            <label for="hero-date-select">Travel Window</label>
            <select id="hero-date-select" name="month">
              <option value="December 2026">December 2026</option>
              <option value="January 2027">January 2027</option>
              <option value="February 2027">February 2027</option>
              <option value="Spring 2027 (Mar–May)">Spring 2027 (Mar–May)</option>
            </select>
          </div>

          <div class="search-field">
            <label for="hero-travellers-select">Travellers</label>
            <select id="hero-travellers-select" name="travellers">
              <option value="2">2 Guests (Couple)</option>
              <option value="4">4 Guests (Family)</option>
              <option value="6">6 Guests (Private Group)</option>
              <option value="1">1 Solo Traveller</option>
            </select>
          </div>

          <button type="submit" id="hero-search-submit" class="btn-gold">
            Explore Journeys
          </button>
        </form>

        <div class="hero-micro-trust tabular">
          <span><span class="gold-star">★ 4.9</span> Rated on Google (${BUSINESS_CREDENTIALS.googleReviewCount} Verified Reviews)</span>
          <span>·</span>
          <span>Govt. of India Approved (${BUSINESS_CREDENTIALS.motLicense})</span>
          <span>·</span>
          <span>Zero Hidden Charges Guarantee</span>
        </div>
      </div>
    </section>

    <!-- PROOF OF BUSINESS CREDENTIALS RIBBON -->
    <section class="trust-ribbon" aria-label="Business Credentials">
      <div class="container trust-ribbon-grid tabular">
        <div class="trust-stat">
          <strong>10+ Years in Business</strong>
          <span>4,800+ private trips crafted since 2016</span>
        </div>
        <div class="trust-stat">
          <strong>100% Line-Item Pricing</strong>
          <span>Permits, private SUV &amp; 5% GST upfront</span>
        </div>
        <div class="trust-stat">
          <strong>MOT &amp; IATA Licensed</strong>
          <span>${BUSINESS_CREDENTIALS.iataNumber} · GST Registered</span>
        </div>
        <div class="trust-stat">
          <strong>Free Date Reschedule</strong>
          <span>Up to 10 days before departure</span>
        </div>
      </div>
    </section>

    <!-- 6 CURATED TRIPS (Not 50 — Curation Feels Premium) -->
    <section class="section-sage" id="curated-journeys-section">
      <div class="container">
        <div class="section-header-row">
          <div>
            <span class="eyebrow">Six Signature Journeys · Winter &amp; Spring</span>
            <h2 class="section-title">Curated by hand, never aggregated.</h2>
            <p class="section-subtitle">
              We host only six signature routes each season so our field teams know every chalet host, boat captain, and mountain driver by first name.
            </p>
          </div>
          <a href="#/destinations" id="home-filter-all-btn" class="btn-outline-forest">Filter by Mood &amp; Terrain →</a>
        </div>

        <div class="packages-grid">
          ${curatedSix.map(renderPackageCard).join("")}
        </div>
      </div>
    </section>

    <!-- WHY ARANYA (WARM CREAM SECTION) -->
    <section class="section-cream">
      <div class="container">
        <div class="section-header-row">
          <div>
            <span class="eyebrow">Why Families &amp; Couples Trust Aranya</span>
            <h2 class="section-title">Calm before, during, and after your flight.</h2>
          </div>
        </div>

        <div class="pillars-grid">
          <div class="pillar-card">
            <span class="pillar-num">01</span>
            <h3>Inspected In Person</h3>
            <p>We reject 8 out of 10 hotels we visit. Every eco-chalet and houseboat here has been slept in by our founders for quietness, water pressure, and warmth.</p>
          </div>
          <div class="pillar-card">
            <span class="pillar-num">02</span>
            <h3>Zero Surprise Add-Ons</h3>
            <p>Snow-chain 4x4 cabs in Manali, Inner Line Permits in Ladakh, and jetty transfers in Andaman are already built into your quote. Nothing asked on arrival.</p>
          </div>
          <div class="pillar-card">
            <span class="pillar-num">03</span>
            <h3>Private Hill-Veteran Drivers</h3>
            <p>Never crammed into shared tempo coaches. Your dedicated Innova Hycross or Crysta stops whenever you spot an orchard or mountain stream.</p>
          </div>
          <div class="pillar-card">
            <span class="pillar-num">04</span>
            <h3>Written Policies Upfront</h3>
            <p>100% refund up to 21 days before travel and one free date reschedule up to 10 days prior—published clearly on every single package page.</p>
          </div>
        </div>

        <!-- REAL HUMAN CONTACT CALLOUT -->
        <div class="curator-callout">
          <div class="curator-person">
            <img src="${esc(BUSINESS_CREDENTIALS.curatorPhoto)}" alt="Priya Nair, Senior Trip Curator at Aranya Journeys" width="72" height="72" loading="lazy" />
            <div>
              <h3>Prefer talking to a real person before deciding?</h3>
              <p>Speak directly with <strong>Priya Nair</strong> (Senior Trip Curator, Bengaluru Studio) — no call-centre scripts, ever.</p>
            </div>
          </div>
          <div style="display: flex; flex-wrap: wrap; gap: 0.75rem;">
            <a href="${buildWhatsAppUrl("Hi Priya, I want to plan a trip to Manali.")}" target="_blank" rel="noopener noreferrer" id="home-curator-wa" class="btn-gold">
              WhatsApp Priya
            </a>
            <a href="tel:+919811472090" id="home-curator-call" class="btn-outline-forest tabular" style="border-color: rgba(255,255,255,0.3); color: var(--cream);">
              Call +91 98114 72090
            </a>
          </div>
        </div>
      </div>
    </section>

    <!-- VERIFIED GOOGLE REVIEWS PREVIEW -->
    <section class="section-sage">
      <div class="container">
        <div class="section-header-row">
          <div>
            <span class="eyebrow">Verified Social Proof</span>
            <h2 class="section-title">Words from unhurried travellers.</h2>
            <p class="section-subtitle">
              Rated <strong class="tabular">4.9 / 5.0</strong> across ${BUSINESS_CREDENTIALS.googleReviewCount} verified Google reviews from families, honeymooners, and solo explorers.
            </p>
          </div>
          <a href="#/reviews" id="home-all-reviews-link" class="btn-outline-forest">Read All Reviews &amp; Stories →</a>
        </div>

        <div class="reviews-grid">
          ${VERIFIED_REVIEWS.slice(0, 3)
            .map(
              (r) => `
            <article class="review-card">
              <div class="review-stars" aria-label="5 out of 5 stars">★★★★★</div>
              <p class="review-quote">“${esc(r.quote)}”</p>
              <div class="reviewer-row">
                <img src="${esc(r.photo)}" alt="${esc(r.name)}" loading="lazy" width="48" height="48" />
                <div class="reviewer-info">
                  <strong>${esc(r.name)} · ${esc(r.city)}</strong>
                  <span>${esc(r.trip)} · ${esc(r.date)}</span>
                </div>
              </div>
            </article>
          `
            )
            .join("")}
        </div>
      </div>
    </section>
  `;

  bindPackageCardClicks();

  const searchForm = document.getElementById("hero-search-form");
  searchForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const dest = document.getElementById("hero-dest-select").value;
    state.searchMonth = document.getElementById("hero-date-select").value;
    state.searchTravellers = Number(document.getElementById("hero-travellers-select").value) || 2;
    if (dest !== "all") {
      window.location.hash = `#/package/${dest}`;
    } else {
      window.location.hash = "#/destinations";
    }
  });
}

/* ==========================================================================
   PAGE 2: DESTINATIONS — Help Them Dream (Filter by Mountains, Beach, Honeymoon, Family, Eco Stays)
   ========================================================================== */
function renderDestinations() {
  const packages = getPackages();
  updateSEO(
    "Explore Curated Destinations — Mountains, Beaches, Honeymoon & Eco Stays | Aranya",
    "Filter bespoke private India journeys by mountains, beach, honeymoon, family comfort, and certified eco-stays."
  );
  updateActiveNav("destinations");
  setMobileBookingBar(null);
  setWhatsAppContext("WhatsApp Priya · Help Me Choose", "Hi Priya, help me choose the best destination for our upcoming dates.");

  const categories = [
    { key: "all", label: "All Curated Journeys" },
    { key: "mountains", label: "Mountains" },
    { key: "beach", label: "Beach & Backwaters" },
    { key: "honeymoon", label: "Honeymoon" },
    { key: "family", label: "Family Friendly" },
    { key: "eco", label: "Eco Stays" }
  ];

  const filtered =
    state.activeCategory === "all"
      ? packages
      : packages.filter((p) => (p.categories || []).includes(state.activeCategory));

  appMain.innerHTML = `
    <section class="section-sage page-top-spacer">
      <div class="container">
        <div class="section-header-row" style="margin-bottom: 1.75rem;">
          <div>
            <span class="eyebrow">Explore By Landscape &amp; Pace</span>
            <h1 class="section-title">Where would you like to wake up?</h1>
            <p class="section-subtitle">
              Every itinerary below can depart privately on your preferred dates. Prices include stays, private chauffeur transfers, permits, and 5% GST.
            </p>
          </div>
          <a href="#/studio" class="btn-outline-forest">+ Add / Edit Package (CMS)</a>
        </div>

        <div class="filter-bar" role="tablist" aria-label="Filter destinations by travel style">
          ${categories
            .map(
              (cat) => `
            <button
              type="button"
              class="filter-pill ${state.activeCategory === cat.key ? "active" : ""}"
              data-cat="${cat.key}"
              id="filter-btn-${cat.key}"
            >
              ${esc(cat.label)}
            </button>
          `
            )
            .join("")}
        </div>

        <div class="packages-grid">
          ${filtered.map(renderPackageCard).join("")}
        </div>
      </div>
    </section>
  `;

  appMain.querySelectorAll(".filter-pill").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.activeCategory = btn.dataset.cat;
      renderDestinations();
    });
  });

  bindPackageCardClicks();
}

/* ==========================================================================
   PAGE 3: PACKAGE DETAIL — Make Them Book (Steps 2, 3, 4 of Booking Flow)
   ========================================================================== */
function renderPackageDetail(slug) {
  const packages = getPackages();
  const pkg = packages.find((p) => p.slug === slug) || packages[0];
  if (!pkg) {
    window.location.hash = "#/";
    return;
  }

  updateSEO(pkg.seoTitle || `${pkg.title} | Aranya Journeys`, pkg.seoDescription || pkg.overview);
  updateActiveNav("destinations");
  setMobileBookingBar(pkg);
  setWhatsAppContext(
    `WhatsApp · ${pkg.title.split(" ")[0]}`,
    `Hi, I want to plan the ${pkg.title} (${pkg.duration}) for ${state.searchTravellers} travellers.`
  );

  let travellers = state.searchTravellers || 2;
  let payMode = "token"; // "token" (20%) or "full" (100%)
  let availabilityChecked = false;

  const galleryList = pkg.gallery && pkg.gallery.length ? pkg.gallery : [pkg.heroImage];

  appMain.innerHTML = `
    <section class="section-sage page-top-spacer">
      <div class="container">
        <div style="margin-bottom: 1.25rem; display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 0.75rem;">
          <a href="#/destinations" class="card-cta-text" id="back-to-destinations">← Back to All Journeys</a>
          <span class="urgency-note" style="background: var(--cream); border: 1px solid var(--forest-16);">${esc(pkg.urgency)}</span>
        </div>

        <!-- HERO GALLERY WITH iOS GLASS BADGES & PRICE OVERLAY -->
        <div class="detail-hero-banner">
          <img id="detail-main-photo" src="${esc(galleryList[0])}" alt="${esc(pkg.title)}" />
          <div class="media-top-badges">
            <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
              <span class="glass-badge">${esc(pkg.badge)}</span>
              ${pkg.secondaryBadge ? `<span class="glass-badge">${esc(pkg.secondaryBadge)}</span>` : ""}
              <span class="glass-badge"><span class="gold-star">★</span> ${esc(pkg.rating)} (${pkg.reviewCount || 90} verified)</span>
            </div>
          </div>
          <div class="floating-price-glass">
            <span class="price-amount">${formatINR(pkg.price)}</span>
            <span class="price-unit">per person · all-inclusive</span>
          </div>
        </div>

        <div class="detail-thumbs no-print">
          ${galleryList
            .map(
              (imgSrc, idx) => `
            <button type="button" class="detail-thumb ${idx === 0 ? "active" : ""}" data-photo="${esc(imgSrc)}" aria-label="View photo ${idx + 1}">
              <img src="${esc(imgSrc)}" alt="${esc(pkg.title)} view ${idx + 1}" />
            </button>
          `
            )
            .join("")}
        </div>

        <div class="detail-layout">
          <!-- LEFT COLUMN: OVERVIEW, ITINERARY, PRICE BREAKUP, INCLUSIONS, POLICIES, FAQS -->
          <div>
            <div class="detail-block">
              <span class="eyebrow">${esc(pkg.location)} · ${esc(pkg.duration)}</span>
              <h1 class="section-title" style="margin-bottom: 1rem;">${esc(pkg.title)}</h1>
              <p style="font-size: 1.04rem; color: var(--forest-80); line-height: 1.75;">${esc(pkg.overview)}</p>
            </div>

            <!-- DAY-WISE ITINERARY -->
            <div class="detail-block">
              <h2>Day-Wise Itinerary</h2>
              <div class="itinerary-list">
                ${(pkg.itinerary || [])
                  .map(
                    (item) => `
                  <div class="itinerary-day">
                    <div class="itinerary-day-head">
                      <span class="day-pill">${esc(item.day)}</span>
                      <h3>${esc(item.title)}</h3>
                    </div>
                    <div class="itinerary-meta" style="margin-bottom: 0.5rem;">${esc(item.meta)}</div>
                    <p style="font-size: 0.92rem; color: var(--forest-80);">${esc(item.detail)}</p>
                  </div>
                `
                  )
                  .join("")}
              </div>
            </div>

            <!-- TRANSPARENT LINE-ITEM PRICE BREAKUP -->
            <div class="detail-block">
              <h2>Transparent Price Breakup (Per Person)</h2>
              <div class="breakup-rows tabular">
                ${(pkg.priceBreakup || [])
                  .map(
                    (row) => `
                  <div class="breakup-row">
                    <span>${esc(row.label)}</span>
                    <strong class="price-num">${formatINR(row.amount)}</strong>
                  </div>
                `
                  )
                  .join("")}
                <div class="breakup-row total-row">
                  <span>All-Inclusive Package Total (Per Person)</span>
                  <span class="price-num">${formatINR(pkg.price)}</span>
                </div>
              </div>
              <div class="no-hidden-banner">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>
                <span><strong>No Hidden Charges Guarantee:</strong> 5% GST, local union snow/island vehicles, driver stay, and permits are already included above.</span>
              </div>
            </div>

            <!-- INCLUSIONS & EXCLUSIONS -->
            <div class="detail-block">
              <h2>What Is Included &amp; What Is Not</h2>
              <div class="inc-exc-grid">
                <div>
                  <h3 style="font-size: 1.1rem; margin-bottom: 0.85rem;">Included in Your Fare</h3>
                  <ul class="clean-list">
                    ${(pkg.inclusions || [])
                      .map((inc) => `<li><span style="color: var(--forest); font-weight: 700;">✓</span> <span>${esc(inc)}</span></li>`)
                      .join("")}
                  </ul>
                </div>
                <div>
                  <h3 style="font-size: 1.1rem; margin-bottom: 0.85rem;">Not Included (Transparently)</h3>
                  <ul class="clean-list">
                    ${(pkg.exclusions || [])
                      .map((exc) => `<li><span style="color: var(--forest-62); font-weight: 700;">–</span> <span>${esc(exc)}</span></li>`)
                      .join("")}
                  </ul>
                </div>
              </div>
            </div>

            <!-- POLICIES UPFRONT ON EVERY PACKAGE PAGE -->
            <div class="detail-block">
              <h2>Cancellation, Refund &amp; Reschedule Policy</h2>
              <div class="policy-grid">
                <div class="policy-box">
                  <strong>100% Free Cancellation</strong>
                  <p>Cancel up to 21 days before departure for a 100% full refund to your original UPI or bank card—zero cancellation fees.</p>
                </div>
                <div class="policy-box">
                  <strong>1 Free Date Reschedule</strong>
                  <p>Weather change or work emergency? Shift your batch dates once for free up to 10 days before travel.</p>
                </div>
                <div class="policy-box">
                  <strong>4-Day Express Refunds</strong>
                  <p>20–10 days prior: 75% refund. Within 10 days: 50% credit note valid 18 months. Refunds settle in 4 business days.</p>
                </div>
              </div>
            </div>

            <!-- DESTINATION SEO FAQS -->
            ${
              pkg.faqs && pkg.faqs.length
                ? `
              <div class="detail-block">
                <h2>Frequently Asked Questions</h2>
                <div>
                  ${pkg.faqs
                    .map(
                      (f, idx) => `
                    <details class="faq-item" ${idx === 0 ? "open" : ""}>
                      <summary>${esc(f.q)} <span>+</span></summary>
                      <p>${esc(f.a)}</p>
                    </details>
                  `
                    )
                    .join("")}
                </div>
              </div>
            `
                : ""
            }
          </div>

          <!-- RIGHT COLUMN: STICKY 5-STEP BOOKING FLOW WIDGET -->
          <aside id="booking-widget-card" class="booking-sidebar no-print" aria-label="Check Availability and Book">
            <div class="booking-price-header">
              <div>
                <span style="font-size: 0.76rem; text-transform: uppercase; letter-spacing: 0.08em; color: var(--forest-62); font-weight: 600;">All-Inclusive Fare</span>
                <div style="margin-top: 0.25rem;">
                  <span class="price-highlight-chip">${formatINR(pkg.price)}</span>
                  <span style="font-size: 0.82rem; color: var(--forest-62);"> / person</span>
                </div>
              </div>
              <div style="text-align: right; font-size: 0.82rem;">
                <span class="gold-star">★</span> <strong>${esc(pkg.rating)}</strong>
                <div style="color: var(--forest-62);">${esc(pkg.duration)}</div>
              </div>
            </div>

            <div style="margin-bottom: 1rem; font-size: 0.82rem; font-weight: 600; background: var(--sage); padding: 0.6rem 0.85rem; border-radius: 12px;">
              Honest Batch Status: ${esc(pkg.urgency)}
            </div>

            <form id="package-booking-form">
              <div class="form-group">
                <label for="book-batch">1. Choose Batch or Private Date</label>
                <select id="book-batch" class="form-control" required>
                  ${(pkg.batches || ["12 Dec – 17 Dec", "Custom Private Dates"])
                    .map((b) => `<option value="${esc(b)}">${esc(b)}</option>`)
                    .join("")}
                  <option value="Custom Private Departure Dates">Custom Private Departure Dates</option>
                </select>
              </div>

              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem;">
                <div class="form-group">
                  <label for="book-travellers">2. Travellers</label>
                  <select id="book-travellers" class="form-control">
                    ${[1, 2, 3, 4, 5, 6, 8]
                      .map((n) => `<option value="${n}" ${n === travellers ? "selected" : ""}>${n} ${n === 1 ? "Traveller" : "Travellers"}</option>`)
                      .join("")}
                  </select>
                </div>
                <div class="form-group">
                  <label for="book-payment-method">Payment Mode</label>
                  <select id="book-payment-method" class="form-control">
                    <option value="UPI (GPay / PhonePe)">UPI (Zero Fee)</option>
                    <option value="Visa / Mastercard">Visa / Mastercard</option>
                    <option value="NetBanking / NEFT">NetBanking</option>
                  </select>
                </div>
              </div>

              <div class="form-group">
                <label for="book-guest-name">3. Your Full Name</label>
                <input type="text" id="book-guest-name" class="form-control" placeholder="e.g. Rohan &amp; Meera Sharma" required />
              </div>

              <div class="form-group">
                <label for="book-guest-phone">WhatsApp Number (For Instant Confirmation)</label>
                <input type="tel" id="book-guest-phone" class="form-control tabular" placeholder="+91 98XXX XXXXX" required />
              </div>

              <!-- STEP 4: TOKEN VS FULL AMOUNT -->
              <div class="pay-split-options" role="radiogroup" aria-label="Choose Token or Full Payment">
                <button type="button" class="pay-option-card selected" data-paymode="token" id="pay-opt-token">
                  <strong>Pay 20% Token</strong>
                  <span id="token-amount-readout" class="tabular">${formatINR(Math.round(pkg.price * travellers * 0.2))} now</span>
                </button>
                <button type="button" class="pay-option-card" data-paymode="full" id="pay-opt-full">
                  <strong>Pay 100% Full</strong>
                  <span id="full-amount-readout" class="tabular">${formatINR(pkg.price * travellers)} total</span>
                </button>
              </div>

              <div id="availability-status-box" style="display: none; margin-bottom: 0.9rem; padding: 0.75rem 0.9rem; border-radius: 12px; background: var(--sage); border: 1px solid var(--forest-16); font-size: 0.84rem;"></div>

              <div class="tabular" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; font-size: 0.9rem;">
                <span>Total Trip Value (<span id="summary-pax-count">${travellers}</span> guests):</span>
                <strong id="summary-grand-total">${formatINR(pkg.price * travellers)}</strong>
              </div>

              <button type="button" id="check-avail-btn" class="btn-outline-forest" style="width: 100%; margin-bottom: 0.65rem;">
                Step 1: Check Live Seat Availability
              </button>

              <button type="submit" id="book-now-submit-btn" class="btn-gold" style="width: 100%;">
                Reserve Seats &amp; Get WhatsApp Confirmation
              </button>

              <!-- PAYMENT SAFETY BADGES DIRECTLY NEAR BOOK NOW BUTTON -->
              <div class="payment-trust-badges" aria-label="Accepted Secure Payment Methods">
                <span class="pay-badge">UPI VERIFIED</span>
                <span class="pay-badge">VISA</span>
                <span class="pay-badge">MASTERCARD</span>
                <span class="pay-badge">256-BIT SSL</span>
              </div>
            </form>

            <div style="margin-top: 1rem; text-align: center; font-size: 0.8rem; color: var(--forest-62);">
              Questions first? Call Priya directly at <a href="tel:+919811472090" class="tabular" style="font-weight: 700; color: var(--forest);">+91 98114 72090</a>
            </div>
          </aside>
        </div>
      </div>
    </section>
  `;

  // Gallery thumbnail switcher
  const mainPhoto = document.getElementById("detail-main-photo");
  appMain.querySelectorAll(".detail-thumb").forEach((thumb) => {
    thumb.addEventListener("click", () => {
      mainPhoto.src = thumb.dataset.photo;
      appMain.querySelectorAll(".detail-thumb").forEach((t) => t.classList.remove("active"));
      thumb.classList.add("active");
    });
  });

  // Live Price Recalculation
  const paxSelect = document.getElementById("book-travellers");
  const tokenBtn = document.getElementById("pay-opt-token");
  const fullBtn = document.getElementById("pay-opt-full");
  const tokenReadout = document.getElementById("token-amount-readout");
  const fullReadout = document.getElementById("full-amount-readout");
  const paxCountEl = document.getElementById("summary-pax-count");
  const grandTotalEl = document.getElementById("summary-grand-total");
  const submitBtn = document.getElementById("book-now-submit-btn");
  const availBox = document.getElementById("availability-status-box");

  function syncPriceUI() {
    travellers = Number(paxSelect.value) || 2;
    state.searchTravellers = travellers;
    const total = pkg.price * travellers;
    const tokenAmt = Math.round(total * 0.2);
    tokenReadout.textContent = `${formatINR(tokenAmt)} now`;
    fullReadout.textContent = `${formatINR(total)} total`;
    paxCountEl.textContent = String(travellers);
    grandTotalEl.textContent = formatINR(total);
    const payableNow = payMode === "token" ? tokenAmt : total;
    submitBtn.textContent = `Pay ${formatINR(payableNow)} & Instant WhatsApp Confirm`;
  }

  paxSelect.addEventListener("change", syncPriceUI);
  tokenBtn.addEventListener("click", () => {
    payMode = "token";
    tokenBtn.classList.add("selected");
    fullBtn.classList.remove("selected");
    syncPriceUI();
  });
  fullBtn.addEventListener("click", () => {
    payMode = "full";
    fullBtn.classList.add("selected");
    tokenBtn.classList.remove("selected");
    syncPriceUI();
  });
  syncPriceUI();

  // Step 3: Live Availability Check
  document.getElementById("check-avail-btn").addEventListener("click", () => {
    const guestName = document.getElementById("book-guest-name").value.trim() || "Guest";
    const batch = document.getElementById("book-batch").value;
    availabilityChecked = true;
    availBox.style.display = "block";
    availBox.innerHTML = `<strong>✓ Availability Confirmed for ${esc(guestName)}:</strong> ${travellers} seat(s) open for <strong>${esc(batch)}</strong>. Held for 20 minutes with zero obligation.`;
  });

  // Step 4 -> Step 5: Complete Reservation & Open Thank You Page
  document.getElementById("package-booking-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const guestName = document.getElementById("book-guest-name").value.trim();
    const guestPhone = document.getElementById("book-guest-phone").value.trim();
    const batch = document.getElementById("book-batch").value;
    const method = document.getElementById("book-payment-method").value;
    const total = pkg.price * travellers;
    const paidAmount = payMode === "token" ? Math.round(total * 0.2) : total;
    const balanceAmount = total - paidAmount;

    state.lastBooking = {
      ref: "ARN-" + Math.floor(100000 + Math.random() * 900000),
      pkg,
      guestName,
      guestPhone,
      batch,
      travellers,
      method,
      payMode,
      total,
      paidAmount,
      balanceAmount,
      bookedAt: new Date().toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })
    };

    window.location.hash = "#/thank-you";
  });
}

/* ==========================================================================
   STEP 5 OF BOOKING FLOW: THANK YOU PAGE (Itinerary PDF, Packing List, Support)
   ========================================================================== */
function renderThankYou() {
  const packages = getPackages();
  const booking = state.lastBooking || {
    ref: "ARN-842910",
    pkg: packages[0],
    guestName: "Valued Traveller",
    guestPhone: "+91 98114 72090",
    batch: packages[0].batches[0],
    travellers: 2,
    method: "UPI (GPay / PhonePe)",
    payMode: "token",
    total: packages[0].price * 2,
    paidAmount: Math.round(packages[0].price * 2 * 0.2),
    balanceAmount: Math.round(packages[0].price * 2 * 0.8),
    bookedAt: "18 Nov 2026"
  };

  updateSEO(`Booking Confirmed (${booking.ref}) | Aranya Journeys`, "Your private itinerary, packing list, and 24/7 trip curator support details.");
  updateActiveNav("");
  setMobileBookingBar(null);

  const waConfirmMsg = `Hi Priya! My booking ${booking.ref} for ${booking.pkg.title} (${booking.batch}, ${booking.travellers} guests) is confirmed. Please share my WhatsApp voucher.`;
  setWhatsAppContext("Send Booking to WhatsApp", waConfirmMsg);

  appMain.innerHTML = `
    <section class="section-sage page-top-spacer">
      <div class="container">
        <div class="detail-block" style="border: 1px solid var(--gold-border);">
          <span class="eyebrow">Booking Confirmed · Reference ${esc(booking.ref)}</span>
          <h1 class="section-title">Pack slow, ${esc(booking.guestName)}. Your sanctuary is reserved.</h1>
          <p style="font-size: 1.04rem; color: var(--forest-80); max-width: 700px; margin-bottom: 1.75rem;">
            Your seat lock and payment receipt have been generated. Senior Trip Curator <strong>Priya Nair</strong> has been assigned to your journey and will message you on <strong>${esc(booking.guestPhone)}</strong> within 15 minutes.
          </p>

          <div class="policy-grid tabular" style="margin-bottom: 1.75rem;">
            <div class="policy-box">
              <strong>Journey &amp; Batch</strong>
              <p>${esc(booking.pkg.title)}<br/>${esc(booking.batch)} · ${booking.travellers} Guests</p>
            </div>
            <div class="policy-box">
              <strong>Payment Summary (${esc(booking.method)})</strong>
              <p>Paid Now: <strong>${formatINR(booking.paidAmount)}</strong><br/>Balance Before Trip: ${formatINR(booking.balanceAmount)}</p>
            </div>
            <div class="policy-box">
              <strong>24×7 Dedicated Support</strong>
              <p>Priya Nair · Senior Curator<br/><strong>+91 98114 72090</strong></p>
            </div>
          </div>

          <div class="no-print" style="display: flex; flex-wrap: wrap; gap: 0.85rem;">
            <a href="${buildWhatsAppUrl(waConfirmMsg)}" target="_blank" rel="noopener noreferrer" id="ty-whatsapp-btn" class="btn-gold">
              Get Instant WhatsApp Confirmation
            </a>
            <button type="button" id="ty-print-pdf-btn" class="btn-forest">
              Download / Print Itinerary PDF
            </button>
            <a href="#/" class="btn-outline-forest">Return Home</a>
          </div>
        </div>

        <div class="detail-layout">
          <!-- PRINTABLE DAY-WISE ITINERARY SUMMARY -->
          <div class="detail-block">
            <h2>Confirmed Day-Wise Itinerary</h2>
            <div class="itinerary-list">
              ${(booking.pkg.itinerary || [])
                .map(
                  (d) => `
                <div class="itinerary-day">
                  <div class="itinerary-day-head">
                    <span class="day-pill">${esc(d.day)}</span>
                    <h3>${esc(d.title)}</h3>
                  </div>
                  <div class="itinerary-meta">${esc(d.meta)}</div>
                  <p style="font-size: 0.9rem; margin-top: 0.4rem;">${esc(d.detail)}</p>
                </div>
              `
                )
                .join("")}
            </div>
          </div>

          <!-- INTERACTIVE PACKING LIST -->
          <div class="detail-block">
            <h2>Your Essential Packing List</h2>
            <p style="font-size: 0.88rem; color: var(--forest-62); margin-bottom: 1.15rem;">
              Tick items off as you pack—included automatically when you print/save your PDF.
            </p>
            <div style="display: flex; flex-direction: column; gap: 0.75rem;">
              ${PACKING_CHECKLIST_ITEMS.map(
                (item, idx) => `
                <label style="display: flex; align-items: flex-start; gap: 0.7rem; background: var(--sage); padding: 0.85rem 1rem; border-radius: 14px; cursor: pointer; font-size: 0.88rem;">
                  <input type="checkbox" data-pack-idx="${idx}" ${state.packingChecked[idx] ? "checked" : ""} style="margin-top: 0.22rem; accent-color: var(--forest);" />
                  <span>${esc(item)}</span>
                </label>
              `
              ).join("")}
            </div>
          </div>
        </div>
      </div>
    </section>
  `;

  document.getElementById("ty-print-pdf-btn").addEventListener("click", () => {
    window.print();
  });

  appMain.querySelectorAll("input[data-pack-idx]").forEach((cb) => {
    cb.addEventListener("change", () => {
      state.packingChecked[cb.dataset.packIdx] = cb.checked;
    });
  });
}

/* ==========================================================================
   PAGE 4: ABOUT — Build Trust (Founder Photo, Story, Office, Licenses, Team)
   ========================================================================== */
function renderAbout() {
  updateSEO(
    "About Aranya Journeys — Founder Story, Licenses & Bengaluru Studio",
    "Meet founder Aarav Mehta and our curation team. MOT Approved, IATA Accredited, and 10+ years crafting quiet private journeys across India."
  );
  updateActiveNav("about");
  setMobileBookingBar(null);
  setWhatsAppContext("WhatsApp Our Studio", "Hi Aarav & Priya, I would love to plan a bespoke journey with Aranya.");

  appMain.innerHTML = `
    <section class="section-sage page-top-spacer">
      <div class="container">
        <div class="two-col-editorial">
          <div class="editorial-photo-frame">
            <img src="${esc(BUSINESS_CREDENTIALS.founderPhoto)}" alt="Aarav Mehta, Founder of Aranya Journeys, at our Bengaluru map and field-journal studio" width="900" height="672" />
          </div>
          <div>
            <span class="eyebrow">Founded 2016 · Bengaluru &amp; Old Manali</span>
            <h1 class="section-title">Why we only sell places we have slept in ourselves.</h1>
            <p style="margin-bottom: 1rem; color: var(--forest-80);">
              In 2016, our founder <strong>Aarav Mehta</strong> left luxury hotel operations after watching family holidays ruined by cramped "sightseeing marathons" and surprise taxi union demands halfway up mountain passes.
            </p>
            <p style="margin-bottom: 1.25rem; color: var(--forest-80);">
              We started Aranya Journeys with two rules: never list more than a handful of deeply vetted routes per season, and publish every rupee—from GST to local snow-4x4 permits—before a guest pays a single token rupee.
            </p>

            <div class="license-grid tabular">
              <div class="license-item">
                <span>Ministry of Tourism Approval</span>
                <strong>${BUSINESS_CREDENTIALS.motLicense}</strong>
              </div>
              <div class="license-item">
                <span>IATA Accreditation</span>
                <strong>${BUSINESS_CREDENTIALS.iataNumber}</strong>
              </div>
              <div class="license-item">
                <span>GST Registration</span>
                <strong>${BUSINESS_CREDENTIALS.gstin}</strong>
              </div>
              <div class="license-item">
                <span>Registered Bengaluru Studio</span>
                <strong>42 Lavelle Road, 560001</strong>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="section-cream">
      <div class="container">
        <div class="section-header-row">
          <div>
            <span class="eyebrow">Real People Behind Every Departure</span>
            <h2 class="section-title">Your journey team, by name.</h2>
          </div>
        </div>

        <div class="reviews-grid">
          <div class="review-card">
            <img src="assets/images/founder-aarav.jpg" alt="Aarav Mehta" style="border-radius: 18px; aspect-ratio: 4/3; object-fit: cover;" />
            <div>
              <h3 style="font-size: 1.25rem;">Aarav Mehta</h3>
              <p style="font-size: 0.82rem; color: var(--forest-62); margin-bottom: 0.5rem;">Founder &amp; Himalayan Route Architect</p>
              <p style="font-size: 0.9rem; color: var(--forest-80);">Personally inspects every mountain chalet across Himachal and Ladakh before winter &amp; spring batches open.</p>
            </div>
          </div>

          <div class="review-card">
            <img src="assets/images/curator-priya.jpg" alt="Priya Nair" style="border-radius: 18px; aspect-ratio: 4/3; object-fit: cover;" />
            <div>
              <h3 style="font-size: 1.25rem;">Priya Nair</h3>
              <p style="font-size: 0.82rem; color: var(--forest-62); margin-bottom: 0.5rem;">Head of Guest Experience · +91 98114 72090</p>
              <p style="font-size: 0.9rem; color: var(--forest-80);">Your single point of contact from your first WhatsApp message until your chauffeur drops you safely home.</p>
            </div>
          </div>

          <div class="review-card">
            <img src="assets/images/reviewer-vikram.jpg" alt="Tenzin & Coastal Field Desk" style="border-radius: 18px; aspect-ratio: 4/3; object-fit: cover;" />
            <div>
              <h3 style="font-size: 1.25rem;">Rohan Menon &amp; Tenzin Dorje</h3>
              <p style="font-size: 0.82rem; color: var(--forest-62); margin-bottom: 0.5rem;">Coastal &amp; High-Altitude Field Leads</p>
              <p style="font-size: 0.9rem; color: var(--forest-80);">Stationed on the ground in Fort Kochi and Old Manali to coordinate private boats, permits, and weather contingencies.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  `;
}

/* ==========================================================================
   PAGE 5: REVIEWS — Social Proof (Google Reviews, Video Story, Traveler Photos)
   ========================================================================== */
function renderReviews() {
  updateSEO(
    "Verified Google Reviews & Traveler Stories (4.9 ★) | Aranya Journeys",
    "Read 642+ verified Google reviews, watch traveler stories, and browse candid photos from families and couples who travelled with Aranya."
  );
  updateActiveNav("reviews");
  setMobileBookingBar(null);
  setWhatsAppContext("WhatsApp Priya · Ask Past Guests", "Hi Priya, I was reading your reviews and would love to plan a trip.");

  appMain.innerHTML = `
    <section class="section-sage page-top-spacer">
      <div class="container">
        <div class="section-header-row">
          <div>
            <span class="eyebrow">642 Verified Google Reviews · 4.9 / 5.0 Average</span>
            <h1 class="section-title">Unscripted memories from real guests.</h1>
            <p class="section-subtitle">
              Every review below includes the guest’s full name, city, exact journey, and month of travel.
            </p>
          </div>
          <a href="${BUSINESS_CREDENTIALS.googleMapsUrl}" target="_blank" rel="noopener noreferrer" class="btn-outline-forest">
            Verify on Google Maps ↗
          </a>
        </div>

        <!-- VIDEO TESTIMONIAL STORY BANNER (Click-to-open so zero heavy mobile video autoplays!) -->
        <div class="video-story-banner">
          <img src="assets/images/traveler-chai.jpg" alt="Siddharth and Meera sharing morning chai overlooking misty Himalayan pines" />
          <div class="video-story-content">
            <span class="glass-badge" style="margin-bottom: 1rem;">Traveler Video Story · 2:14</span>
            <h3>“For six days, nobody rushed us once.”</h3>
            <p style="opacity: 0.92; margin-bottom: 1.35rem; font-size: 0.96rem;">
              Watch Siddharth &amp; Meera Kulkarni’s visual diary from Old Manali &amp; Sethan—from woodfire breakfasts to waking up above the clouds.
            </p>
            <button type="button" id="open-video-story-btn" class="btn-gold">
              ▶ Watch Traveler Story Reel
            </button>
          </div>
        </div>

        <div class="reviews-grid">
          ${VERIFIED_REVIEWS.map(
            (r) => `
            <article class="review-card">
              <div style="display: flex; justify-content: space-between; align-items: center;">
                <span class="review-stars">★★★★★</span>
                <span style="font-size: 0.74rem; font-weight: 600; color: var(--forest-62);">Google Verified</span>
              </div>
              <p class="review-quote">“${esc(r.quote)}”</p>
              <div class="reviewer-row">
                <img src="${esc(r.photo)}" alt="${esc(r.name)}" loading="lazy" width="48" height="48" />
                <div class="reviewer-info">
                  <strong>${esc(r.name)} · ${esc(r.city)}</strong>
                  <span>${esc(r.trip)} · ${esc(r.date)}</span>
                </div>
              </div>
            </article>
          `
          ).join("")}
        </div>
      </div>
    </section>
  `;

  document.getElementById("open-video-story-btn").addEventListener("click", () => {
    modalRoot.innerHTML = `
      <div class="modal-backdrop" id="story-modal-backdrop">
        <div class="modal-card">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
            <span class="eyebrow" style="margin: 0;">Verified Guest Film Transcript &amp; Stills</span>
            <button type="button" id="close-story-modal" class="btn-outline-forest" style="padding: 0.35rem 0.85rem;">Close ✕</button>
          </div>
          <img src="assets/images/traveler-chai.jpg" alt="Traveler morning chai" style="border-radius: 16px; margin-bottom: 1.25rem;" />
          <h3 style="font-size: 1.4rem; margin-bottom: 0.65rem;">Siddharth &amp; Meera · Pune → Sethan &amp; Old Manali</h3>
          <p style="font-size: 0.94rem; color: var(--forest-80); margin-bottom: 1rem;">
            “We skipped heavy video streaming on mobile to keep pages instant—here are the highlights from our December batch: waking up in a heated cedar room facing Deo Tibba, having our 4x4 snow jeep waiting without paying extra union surcharges, and sharing brass-cup masala chai on a quiet stone terrace at 7:00 AM.”
          </p>
          <a href="#/package/manali-honeymoon-package" id="story-modal-cta" class="btn-gold" style="width: 100%;">Explore Their Exact Manali Itinerary</a>
        </div>
      </div>
    `;
    const close = () => {
      modalRoot.innerHTML = "";
    };
    document.getElementById("close-story-modal").addEventListener("click", close);
    document.getElementById("story-modal-cta").addEventListener("click", close);
    document.getElementById("story-modal-backdrop").addEventListener("click", (e) => {
      if (e.target.id === "story-modal-backdrop") close();
    });
  });
}

/* ==========================================================================
   PAGE 6: BLOG / GUIDES — Get Google Traffic (Best Time, Visa/Permits, Packing List)
   ========================================================================== */
function renderGuides(selectedSlug = null) {
  updateActiveNav("guides");
  setMobileBookingBar(null);
  setWhatsAppContext("WhatsApp · Travel Advice", "Hi Priya, I read your India travel guide and have a quick question.");

  if (selectedSlug) {
    const guide = TRAVEL_GUIDES.find((g) => g.slug === selectedSlug) || TRAVEL_GUIDES[0];
    updateSEO(`${guide.title} | Aranya Field Guides`, guide.excerpt);

    appMain.innerHTML = `
      <section class="section-sage page-top-spacer">
        <div class="container" style="max-width: 880px;">
          <a href="#/guides" class="card-cta-text" style="margin-bottom: 1.25rem;">← Back to All Field Guides</a>
          <div class="detail-block">
            <span class="eyebrow">${esc(guide.category)} · ${esc(guide.readTime)} · ${esc(guide.updated)}</span>
            <h1 class="section-title">${esc(guide.title)}</h1>
            <img src="${esc(guide.image)}" alt="${esc(guide.title)}" style="border-radius: 18px; margin: 1.5rem 0; aspect-ratio: 16/9; object-fit: cover; width: 100%;" />
            ${guide.sections
              .map(
                (s) => `
              <div style="margin-bottom: 1.75rem;">
                <h2 style="font-size: 1.35rem; margin-bottom: 0.55rem;">${esc(s.heading)}</h2>
                <p style="color: var(--forest-80); font-size: 0.98rem; line-height: 1.75;">${esc(s.body)}</p>
              </div>
            `
              )
              .join("")}
            <div style="padding-top: 1.25rem; border-top: 1px solid var(--forest-10); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
              <strong>Ready to experience this season firsthand?</strong>
              <a href="#/package/${esc(guide.relatedPackageSlug)}" class="btn-gold">View Recommended Itinerary →</a>
            </div>
          </div>
        </div>
      </section>
    `;
    return;
  }

  updateSEO(
    "India Travel Field Guides — Best Time to Visit, Permits & Packing Lists | Aranya",
    "Practical, zero-fluff guides on the best months to visit Manali, Kerala & Andaman, Inner Line Permits, and minimalist packing lists."
  );

  appMain.innerHTML = `
    <section class="section-sage page-top-spacer">
      <div class="container">
        <div class="section-header-row">
          <div>
            <span class="eyebrow">Field Notes &amp; Planning Guides</span>
            <h1 class="section-title">Honest answers before you pack.</h1>
            <p class="section-subtitle">
              Written by our route architects—covering weather windows, permit rules, and exactly what fits in a single cabin-plus-check-in bag.
            </p>
          </div>
        </div>

        <div class="guides-grid">
          ${TRAVEL_GUIDES.map(
            (g) => `
            <article class="guide-card" data-guide-slug="${esc(g.slug)}" tabindex="0" role="link">
              <div class="guide-card-img">
                <img src="${esc(g.image)}" alt="${esc(g.title)}" loading="lazy" />
              </div>
              <div class="guide-card-body">
                <span class="eyebrow" style="margin-bottom: 0.2rem;">${esc(g.category)} · ${esc(g.readTime)}</span>
                <h2 style="font-size: 1.28rem; line-height: 1.3;">${esc(g.title)}</h2>
                <p style="font-size: 0.9rem; color: var(--forest-80); flex: 1;">${esc(g.excerpt)}</p>
                <span class="card-cta-text" style="margin-top: 0.5rem;">Read Complete Guide →</span>
              </div>
            </article>
          `
          ).join("")}
        </div>
      </div>
    </section>
  `;

  appMain.querySelectorAll(".guide-card[data-guide-slug]").forEach((card) => {
    card.addEventListener("click", () => {
      window.location.hash = `#/guide/${card.dataset.guideSlug}`;
    });
  });
}

/* ==========================================================================
   PAGE 7: CONTACT / BOOK — Close the Sale (WhatsApp, Form, Phone, Map, Hours)
   ========================================================================== */
function renderContact() {
  updateSEO(
    "Contact Aranya Journeys — Speak with Priya Nair or Visit Our Bengaluru Studio",
    "Plan your trip via WhatsApp, direct phone (+91 98114 72090), or visit our Lavelle Road studio in Bengaluru."
  );
  updateActiveNav("contact");
  setMobileBookingBar(null);
  setWhatsAppContext("WhatsApp Priya Now", "Hi, I want to plan a trip to Manali.");

  appMain.innerHTML = `
    <section class="section-sage page-top-spacer">
      <div class="container">
        <div class="detail-layout">
          <!-- BESPOKE INQUIRY FORM -->
          <div class="detail-block">
            <span class="eyebrow">Response Within 20 Minutes During Studio Hours</span>
            <h1 class="section-title" style="font-size: 2.2rem;">Tell us how you want your days to feel.</h1>
            <p style="color: var(--forest-80); margin-bottom: 1.5rem;">
              In India, the best journeys begin with a calm conversation. Start straight on WhatsApp or leave a note below—Priya will reply personally with a custom day-by-day plan and exact total price.
            </p>

            <div style="margin-bottom: 1.75rem;">
              <a
                href="${buildWhatsAppUrl("Hi, I want to plan a trip to Manali.")}"
                target="_blank"
                rel="noopener noreferrer"
                id="contact-whatsapp-hero-btn"
                class="btn-gold"
                style="width: 100%;"
              >
                Start Instant WhatsApp Chat with Priya (+91 98114 72090)
              </a>
            </div>

            <form id="contact-inquiry-form">
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div class="form-group">
                  <label for="cnt-name">Your Name</label>
                  <input type="text" id="cnt-name" class="form-control" placeholder="Aditi &amp; Karthik" required />
                </div>
                <div class="form-group">
                  <label for="cnt-phone">Phone / WhatsApp</label>
                  <input type="tel" id="cnt-phone" class="form-control tabular" placeholder="+91 98XXX XXXXX" required />
                </div>
              </div>

              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div class="form-group">
                  <label for="cnt-dest">Preferred Region</label>
                  <select id="cnt-dest" class="form-control">
                    <option value="Manali & Sethan">Manali &amp; Sethan Sanctuary</option>
                    <option value="Kerala Backwaters">Kumarakom &amp; Marari</option>
                    <option value="Andaman Islands">Havelock &amp; Neil Islands</option>
                    <option value="Ladakh Valleys">Ladakh &amp; Turtuk</option>
                    <option value="Coorg Rainforest">Coorg Rainforest Estate</option>
                    <option value="Udaipur & Jawai">Udaipur &amp; Jawai</option>
                  </select>
                </div>
                <div class="form-group">
                  <label for="cnt-dates">Approximate Month &amp; Guests</label>
                  <input type="text" id="cnt-dates" class="form-control" placeholder="e.g. Mid-Dec · 2 Adults" required />
                </div>
              </div>

              <div class="form-group">
                <label for="cnt-notes">Anything Special? (Anniversary, Senior Parents, Dietary Notes)</label>
                <textarea id="cnt-notes" rows="3" class="form-control" placeholder="We prefer quiet mountain views, slow mornings, and vegetarian meals..."></textarea>
              </div>

              <button type="submit" id="cnt-submit-btn" class="btn-forest" style="width: 100%;">
                Request Custom Itinerary &amp; Line-Item Quote
              </button>
              <div id="cnt-feedback" style="display: none; margin-top: 1rem; padding: 1rem; border-radius: 14px; background: var(--sage); font-weight: 500;"></div>
            </form>
          </div>

          <!-- REAL HUMAN CURATOR + STUDIO MAP & WORKING HOURS -->
          <div>
            <div class="detail-block">
              <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1.25rem;">
                <img src="${esc(BUSINESS_CREDENTIALS.curatorPhoto)}" alt="Priya Nair" style="width: 68px; height: 68px; border-radius: 50%; object-fit: cover; border: 2px solid var(--gold);" />
                <div>
                  <h2 style="font-size: 1.3rem; margin-bottom: 0.15rem;">Priya Nair</h2>
                  <p style="font-size: 0.84rem; color: var(--forest-62);">Senior Trip Curator · 8 Years at Aranya</p>
                </div>
              </div>
              <div class="tabular" style="display: flex; flex-direction: column; gap: 0.65rem; font-size: 0.92rem;">
                <div><strong>Direct Phone:</strong> <a href="tel:+919811472090" style="text-decoration: underline;">+91 98114 72090</a></div>
                <div><strong>Email:</strong> <a href="mailto:concierge@aranyajourneys.in">concierge@aranyajourneys.in</a></div>
                <div><strong>Working Hours:</strong> ${esc(BUSINESS_CREDENTIALS.workingHours)}</div>
              </div>
            </div>

            <!-- TOPOGRAPHIC STUDIO LOCATION MAP -->
            <div class="studio-map-card">
              <span class="eyebrow" style="color: var(--gold);">Registered Studio &amp; Field Desk</span>
              <h3 style="color: var(--cream); font-size: 1.35rem; margin-bottom: 0.65rem;">Bengaluru HQ · Lavelle Road</h3>
              <p style="color: var(--cream-72); font-size: 0.88rem; margin-bottom: 1.25rem;">
                ${esc(BUSINESS_CREDENTIALS.hqAddress)}<br/>
                <span style="opacity: 0.85;">Himalayan Desk: ${esc(BUSINESS_CREDENTIALS.fieldAddress)}</span>
              </p>

              <!-- Crisp Embedded SVG Studio Map -->
              <div style="border-radius: 16px; overflow: hidden; border: 1px solid rgba(255,255,255,0.18); margin-bottom: 1rem; background: #143828;">
                <svg viewBox="0 0 480 200" width="100%" height="180" role="img" aria-label="Map showing Aranya Studio on Lavelle Road near Cubbon Park, Bengaluru">
                  <path d="M0 40 Q140 20 280 55 T480 35" fill="none" stroke="#C9A86A" stroke-opacity="0.22" stroke-width="1.5"/>
                  <path d="M0 110 Q180 85 310 125 T480 105" fill="none" stroke="#E8EFEA" stroke-opacity="0.18" stroke-width="2"/>
                  <line x1="210" y1="0" x2="235" y2="200" stroke="#F7F3EB" stroke-opacity="0.32" stroke-width="4"/>
                  <line x1="40" y1="95" x2="450" y2="82" stroke="#F7F3EB" stroke-opacity="0.25" stroke-width="3"/>
                  <rect x="70" y="30" width="110" height="50" rx="12" fill="#E8EFEA" fill-opacity="0.09"/>
                  <text x="125" y="59" fill="#E8EFEA" fill-opacity="0.7" font-size="11" text-anchor="middle" font-family="Inter, sans-serif">Cubbon Park</text>
                  <circle cx="222" cy="89" r="16" fill="#C9A86A" fill-opacity="0.28"/>
                  <circle cx="222" cy="89" r="7" fill="#C9A86A"/>
                  <text x="244" y="86" fill="#FFFFFF" font-size="12" font-weight="600" font-family="Inter, sans-serif">Aranya Studio · 42 Lavelle Rd</text>
                  <text x="244" y="103" fill="#E8EFEA" fill-opacity="0.75" font-size="10" font-family="Inter, sans-serif">12.9716° N, 77.5993° E</text>
                </svg>
              </div>

              <a href="${BUSINESS_CREDENTIALS.googleMapsUrl}" target="_blank" rel="noopener noreferrer" class="btn-gold btn-gold-sm">
                Open Directions in Google Maps ↗
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  `;

  document.getElementById("contact-inquiry-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("cnt-name").value.trim();
    const dest = document.getElementById("cnt-dest").value;
    const dates = document.getElementById("cnt-dates").value.trim();
    const fb = document.getElementById("cnt-feedback");
    const waFollowup = buildWhatsAppUrl(`Hi Priya, I'm ${name}. I'd love a quote for ${dest} (${dates}).`);
    fb.style.display = "block";
    fb.innerHTML = `Thank you, <strong>${esc(name)}</strong>! Your request is queued with Priya Nair. Want an instant reply right now? <a href="${waFollowup}" target="_blank" rel="noopener noreferrer" style="text-decoration: underline; font-weight: 700;">Tap here to open in WhatsApp →</a>`;
  });
}

/* ==========================================================================
   SIMPLE CLIENT CMS (#/studio) — Add Package, Change Price, Upload Photo Without Code
   ========================================================================== */
function renderStudioCMS() {
  const packages = getPackages();
  updateSEO("Client Package CMS — Update Prices & Add Packages | Aranya Journeys", "No-code CMS to edit prices, seat urgency, and add destination packages.");
  updateActiveNav("studio");
  setMobileBookingBar(null);

  appMain.innerHTML = `
    <section class="section-sage page-top-spacer">
      <div class="container">
        <div class="section-header-row">
          <div>
            <span class="eyebrow">No-Code Client CMS · Instant Live Updates</span>
            <h1 class="section-title">Manage Packages, Prices &amp; Photos</h1>
            <p class="section-subtitle">
              Change any package price, update batch seat urgency, or publish a new trip with a photo upload—no code required. Changes save immediately to browser storage.
            </p>
          </div>
          <button type="button" id="cms-reset-btn" class="btn-outline-forest">Reset to Default 6 Packages</button>
        </div>

        <div class="detail-layout">
          <!-- EXISTING PACKAGES QUICK EDITOR -->
          <div class="detail-block">
            <h2>Quick-Edit Live Packages (${packages.length})</h2>
            <div style="display: flex; flex-direction: column; gap: 1.15rem;">
              ${packages
                .map(
                  (p, idx) => `
                <div style="background: var(--sage); padding: 1.15rem; border-radius: 18px; border: 1px solid var(--forest-10); display: grid; grid-template-columns: 84px 1fr; gap: 1rem; align-items: center;">
                  <img src="${esc(p.heroImage)}" alt="${esc(p.title)}" style="width: 84px; height: 68px; object-fit: cover; border-radius: 12px;" />
                  <div>
                    <strong style="font-size: 1rem; display: block; margin-bottom: 0.45rem;">${esc(p.title)}</strong>
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1.4fr auto; gap: 0.5rem; align-items: center;">
                      <input type="number" class="form-control tabular" data-edit-price="${idx}" value="${p.price}" aria-label="Price in INR" style="padding: 0.48rem 0.65rem; background: var(--cream);" />
                      <select class="form-control" data-edit-badge="${idx}" style="padding: 0.48rem 0.65rem; background: var(--cream);">
                        ${["Bestseller", "Limited Seats", "New", "Eco Stay"]
                          .map((b) => `<option value="${b}" ${p.badge === b ? "selected" : ""}>${b}</option>`)
                          .join("")}
                      </select>
                      <input type="text" class="form-control" data-edit-urgency="${idx}" value="${esc(p.urgency)}" aria-label="Urgency label" style="padding: 0.48rem 0.65rem; background: var(--cream);" />
                      <button type="button" class="btn-gold btn-gold-sm" data-save-idx="${idx}">Save</button>
                    </div>
                  </div>
                </div>
              `
                )
                .join("")}
            </div>
            <div id="cms-toast" style="display: none; margin-top: 1rem; padding: 0.85rem 1rem; border-radius: 12px; background: var(--forest); color: var(--cream); font-size: 0.88rem;"></div>
          </div>

          <!-- ADD NEW PACKAGE FORM -->
          <div class="detail-block">
            <h2>Add a New Package</h2>
            <form id="cms-add-form">
              <div class="form-group">
                <label for="new-title">Package Title</label>
                <input type="text" id="new-title" class="form-control" placeholder="e.g. Spiti Valley Stargazing Circuit" required />
              </div>
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem;">
                <div class="form-group">
                  <label for="new-loc">Region</label>
                  <input type="text" id="new-loc" class="form-control" placeholder="Himachal · Spiti" required />
                </div>
                <div class="form-group">
                  <label for="new-dur">Duration</label>
                  <input type="text" id="new-dur" class="form-control" placeholder="5 Nights · 6 Days" required />
                </div>
              </div>
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem;">
                <div class="form-group">
                  <label for="new-price">All-Inclusive Price (₹)</label>
                  <input type="number" id="new-price" class="form-control tabular" value="49500" required />
                </div>
                <div class="form-group">
                  <label for="new-cat">Primary Category</label>
                  <select id="new-cat" class="form-control">
                    <option value="mountains">Mountains</option>
                    <option value="beach">Beach</option>
                    <option value="honeymoon">Honeymoon</option>
                    <option value="family">Family</option>
                    <option value="eco">Eco Stay</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label for="new-urgency">Honest Seat Availability Note</label>
                <input type="text" id="new-urgency" class="form-control" value="Only 4 seats left for next batch" required />
              </div>
              <div class="form-group">
                <label for="new-photo-preset">Choose Photo or Upload Below</label>
                <select id="new-photo-preset" class="form-control">
                  <option value="assets/images/hero-himalayas.jpg">Himalayan Cedar Ridge</option>
                  <option value="assets/images/pkg-manali.jpg">Mountain Timber Chalet</option>
                  <option value="assets/images/pkg-kerala.jpg">Emerald Backwaters</option>
                  <option value="assets/images/pkg-andaman.jpg">Untouched Cove Beach</option>
                  <option value="assets/images/pkg-coorg.jpg">Misty Rainforest Veranda</option>
                </select>
              </div>
              <div class="form-group">
                <label for="new-photo-upload">Or Upload Custom Destination Photo</label>
                <input type="file" id="new-photo-upload" accept="image/*" class="form-control" />
              </div>
              <button type="submit" class="btn-gold" style="width: 100%;">Publish Package Live</button>
            </form>
          </div>
        </div>
      </div>
    </section>
  `;

  const showToast = (msg) => {
    const t = document.getElementById("cms-toast");
    t.textContent = msg;
    t.style.display = "block";
    setTimeout(() => {
      if (t) t.style.display = "none";
    }, 3200);
  };

  appMain.querySelectorAll("button[data-save-idx]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const i = Number(btn.dataset.saveIdx);
      const list = getPackages();
      list[i].price = Number(appMain.querySelector(`input[data-edit-price="${i}"]`).value) || list[i].price;
      list[i].badge = appMain.querySelector(`select[data-edit-badge="${i}"]`).value;
      list[i].urgency = appMain.querySelector(`input[data-edit-urgency="${i}"]`).value.trim();
      savePackages(list);
      showToast(`✓ Updated "${list[i].title}" to ${formatINR(list[i].price)} (${list[i].badge})`);
    });
  });

  document.getElementById("cms-reset-btn").addEventListener("click", () => {
    resetPackagesToDefault();
    renderStudioCMS();
  });

  let uploadedDataUrl = null;
  document.getElementById("new-photo-upload").addEventListener("change", (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      uploadedDataUrl = reader.result;
    };
    reader.readAsDataURL(file);
  });

  document.getElementById("cms-add-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const title = document.getElementById("new-title").value.trim();
    const price = Number(document.getElementById("new-price").value) || 45000;
    const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") + "-" + Date.now().toString().slice(-3);
    const img = uploadedDataUrl || document.getElementById("new-photo-preset").value;
    const cat = document.getElementById("new-cat").value;

    const newPkg = {
      id: "pkg-" + Date.now(),
      slug,
      title,
      location: document.getElementById("new-loc").value.trim(),
      duration: document.getElementById("new-dur").value.trim(),
      price,
      rating: "4.9",
      reviewCount: 18,
      badge: "New",
      secondaryBadge: "Curated",
      categories: [cat],
      urgency: document.getElementById("new-urgency").value.trim(),
      batches: ["15 Jan – 20 Jan", "02 Feb – 07 Feb"],
      heroImage: img,
      gallery: [img],
      summaryLine: "Hand-inspected boutique stays · Private SUV · Daily breakfasts & dinners · 5% GST included",
      overview: `Bespoke private departure to ${title}, crafted with transparent line-item pricing and dedicated local support.`,
      priceBreakup: [
        { label: "Boutique Hand-Inspected Stays", amount: Math.round(price * 0.6) },
        { label: "Private Chauffeur Vehicle & Transfers", amount: Math.round(price * 0.22) },
        { label: "Meals, Guided Walks, Permits & 5% GST", amount: price - Math.round(price * 0.6) - Math.round(price * 0.22) }
      ],
      inclusions: ["Hand-inspected stays", "Private vehicle throughout", "Breakfasts & curated dinners", "All permits & 5% GST"],
      exclusions: ["Mainline airfare to arrival airport"],
      itinerary: [
        { day: "Day 1", title: "Private Arrival & Boutique Sanctuary Check-in", meta: "Airport Pickup · Dinner Included", detail: "Smooth transfer to your quiet heritage/eco property." },
        { day: "Day 2–5", title: "Unhurried Local Immersion & Guided Trails", meta: "Private Vehicle · Flexible Pace", detail: "Explore off-crowd trails, local kitchens, and scenic viewpoints at your own rhythm." }
      ],
      faqs: [{ q: "Are all taxes and permits included?", a: "Yes, 5% GST and local permits are included upfront with zero hidden charges." }]
    };

    const list = [newPkg, ...getPackages()];
    savePackages(list);
    window.location.hash = `#/package/${slug}`;
  });
}

/* ==========================================================================
   LEGAL PAGES — Terms, Privacy, Refund Policy
   ========================================================================== */
function renderLegal(docType) {
  updateActiveNav("");
  setMobileBookingBar(null);

  const docs = {
    terms: {
      title: "Terms & Conditions",
      body: [
        "All journeys operated by Aranya Bespoke Journeys Pvt. Ltd. (MOT License MOT/TOUR/2016/08419, GSTIN 29AABCA8419K1Z5) include every line item stated on the respective itinerary page with zero hidden local surcharges.",
        "A 20% refundable token deposit locks live stay inventory and dedicated chauffeur vehicles; remaining balance is payable 14 days prior to travel via UPI, Visa/Mastercard, or NEFT.",
        "Guests must carry original valid government-issued photo identification (Passport, Aadhaar, or Voter ID) required by regional forest and aviation authorities."
      ]
    },
    privacy: {
      title: "Privacy Policy",
      body: [
        "We collect only your name, phone/WhatsApp number, and ID details strictly required for hotel check-ins, Inner Line Permits, and flight/ferry manifests.",
        "Aranya Journeys never sells, rents, or shares your contact details with third-party marketing agencies or timeshare operators.",
        "You may request complete erasure of your travel records anytime by emailing concierge@aranyajourneys.in."
      ]
    },
    refund: {
      title: "Cancellation, Refund & Free Reschedule Policy",
      body: [
        "21+ Days Before Departure: 100% full refund back to your original payment method (UPI / Card / Bank) with zero deduction.",
        "Up to 10 Days Before Departure: One complimentary date reschedule to any open batch within 12 months, or 75% cash refund.",
        "Within 10 Days of Departure: 50% transferable travel credit valid for 18 months across any Aranya destination. Approved refunds settle within 4 business days."
      ]
    }
  };

  const doc = docs[docType] || docs.refund;
  updateSEO(`${doc.title} | Aranya Journeys`, doc.body[0]);

  appMain.innerHTML = `
    <section class="section-sage page-top-spacer">
      <div class="container" style="max-width: 820px;">
        <div class="detail-block">
          <span class="eyebrow">Transparent Legal &amp; Guest Protection</span>
          <h1 class="section-title">${esc(doc.title)}</h1>
          <div style="display: flex; flex-direction: column; gap: 1rem; margin-top: 1.25rem; color: var(--forest-80);">
            ${doc.body.map((p) => `<p>${esc(p)}</p>`).join("")}
          </div>
          <div style="margin-top: 2rem; display: flex; gap: 0.75rem; flex-wrap: wrap;">
            <a href="#/legal/refund" class="btn-outline-forest">Refund Policy</a>
            <a href="#/legal/terms" class="btn-outline-forest">Terms</a>
            <a href="#/legal/privacy" class="btn-outline-forest">Privacy</a>
          </div>
        </div>
      </div>
    </section>
  `;
}

/* ==========================================================================
   HASH ROUTER & GLOBAL LISTENERS
   ========================================================================== */
function handleRoute() {
  const hash = window.location.hash || "#/";
  const parts = hash.replace(/^#\/?/, "").split("/");
  const root = parts[0] || "";
  const param = parts[1] || "";

  modalRoot.innerHTML = "";
  window.scrollTo({ top: 0, behavior: "instant" });

  const isHomeHero = root === "";
  updateHeaderGlassMode(isHomeHero);

  switch (root) {
    case "":
      renderHome();
      break;
    case "destinations":
      renderDestinations();
      break;
    case "package":
      renderPackageDetail(param);
      break;
    case "thank-you":
      renderThankYou();
      break;
    case "about":
      renderAbout();
      break;
    case "reviews":
      renderReviews();
      break;
    case "guides":
      renderGuides();
      break;
    case "guide":
      renderGuides(param);
      break;
    case "contact":
      renderContact();
      break;
    case "studio":
      renderStudioCMS();
      break;
    case "legal":
      renderLegal(param);
      break;
    default:
      renderHome();
  }
}

window.addEventListener("hashchange", handleRoute);
window.addEventListener(
  "scroll",
  () => {
    const isHome = !window.location.hash || window.location.hash === "#/";
    updateHeaderGlassMode(isHome);
  },
  { passive: true }
);

document.getElementById("mobile-menu-toggle").addEventListener("click", () => {
  const isOpen = siteHeader.classList.toggle("menu-open");
  document.getElementById("mobile-menu-toggle").setAttribute("aria-expanded", String(isOpen));
});

handleRoute();
